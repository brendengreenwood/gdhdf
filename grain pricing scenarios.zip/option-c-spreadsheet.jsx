// Option C — Spreadsheet grid
// Rows = futures contracts (+ nested delivery windows when expanded).
// Columns = the 4 pricing fields. Like a trading terminal / spreadsheet.
// Revise = click any cell to edit inline in a focused "edit mode" banner,
// OR click the row action to enter a full edit page.

function OptC_Cell({ value, emphasis, muted, width }) {
  return (
    <div style={{
      padding: '10px 12px',
      fontFamily: '"JetBrains Mono", monospace',
      fontSize: emphasis ? '15px' : '13px',
      fontWeight: emphasis ? 700 : 500,
      color: muted ? WF_MUTED : (emphasis ? WF_RED : WF_INK),
      borderRight: `1px solid ${WF_LINE}22`,
      width,
      boxSizing: 'border-box',
    }}>{value}</div>
  );
}

function OptC_ParentRow({ contract, expanded, onToggle, onRevise, editingMode }) {
  const p = PRICING_DATA[contract.code];
  const windowCount = (DELIVERY_WINDOWS[contract.code] || []).length;
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      borderBottom: `1px solid ${WF_LINE}`,
      background: expanded ? WF_PAPER : WF_BG,
      minHeight: '44px',
    }}>
      <div style={{ width: '36px', textAlign: 'center', cursor: 'pointer', fontFamily: '"JetBrains Mono", monospace', fontSize: '14px', borderRight: `1px solid ${WF_LINE}22` }} onClick={onToggle}>
        {expanded ? '▾' : '▸'}
      </div>
      <div style={{ width: '170px', padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '15px', fontWeight: 700 }}>{contract.label}</div>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>
          ZC {contract.code} · {windowCount} windows
        </div>
      </div>
      <OptC_Cell value={formatBasis(p.posted)} emphasis width="110px" />
      <OptC_Cell value={formatBasis(p.max)} width="100px" />
      <OptC_Cell value={`${p.leeway}¢`} width="90px" />
      <OptC_Cell value={`${p.increment}¢`} width="100px" />
      <div style={{ flex: 1, padding: '10px 12px', fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, borderRight: `1px solid ${WF_LINE}22` }}>
        {p.updated} · {p.by}
      </div>
      <div style={{ padding: '6px 10px', display: 'flex', gap: '6px' }}>
        <WfBtn small>view</WfBtn>
        <WfBtn small primary onClick={onRevise}>revise</WfBtn>
      </div>
    </div>
  );
}

function OptC_ChildRow({ window: w, parentCode, editing, onToggleEdit }) {
  const wp = getWindowPricing(parentCode, w.code);
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      borderBottom: `1px dashed ${WF_MUTED}66`,
      background: editing ? '#fff5e6' : WF_BG,
      minHeight: '38px',
    }}>
      <div style={{ width: '36px' }}></div>
      <div style={{ width: '170px', padding: '8px 12px 8px 28px', borderRight: `1px solid ${WF_LINE}22`, display: 'flex', alignItems: 'center', gap: '8px' }}>
        <div style={{
          width: '8px', height: '8px',
          borderLeft: `1.5px solid ${WF_MUTED}`,
          borderBottom: `1.5px solid ${WF_MUTED}`,
          marginRight: '4px',
          marginTop: '-6px',
        }} />
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '12px', fontWeight: 600 }}>
            {w.label}
          </div>
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '9px', color: wp.isOverride ? WF_ACCENT : WF_MUTED }}>
            {wp.isOverride ? '⚑ override' : '↳ inherits'}
          </div>
        </div>
      </div>
      {editing ? (
        <>
          <div style={{ width: '110px', padding: '4px 6px', borderRight: `1px solid ${WF_LINE}22` }}>
            <input defaultValue={wp.posted} style={editCellStyle} />
          </div>
          <div style={{ width: '100px', padding: '4px 6px', borderRight: `1px solid ${WF_LINE}22` }}>
            <input defaultValue={wp.max} style={editCellStyle} />
          </div>
          <div style={{ width: '90px', padding: '4px 6px', borderRight: `1px solid ${WF_LINE}22` }}>
            <input defaultValue={wp.leeway} style={editCellStyle} />
          </div>
          <div style={{ width: '100px', padding: '4px 6px', borderRight: `1px solid ${WF_LINE}22` }}>
            <input defaultValue={wp.increment} style={editCellStyle} />
          </div>
        </>
      ) : (
        <>
          <OptC_Cell value={formatBasis(wp.posted)} emphasis={wp.isOverride} muted={!wp.isOverride} width="110px" />
          <OptC_Cell value={formatBasis(wp.max)} muted width="100px" />
          <OptC_Cell value={`${wp.leeway}¢`} muted width="90px" />
          <OptC_Cell value={`${wp.increment}¢`} muted width="100px" />
        </>
      )}
      <div style={{ flex: 1, padding: '8px 12px', fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED, borderRight: `1px solid ${WF_LINE}22` }}>
        {w.code}
      </div>
      <div style={{ padding: '4px 10px', display: 'flex', gap: '6px' }}>
        <WfBtn small>view</WfBtn>
        <WfBtn small primary={editing} onClick={onToggleEdit}>{editing ? 'save' : 'revise'}</WfBtn>
      </div>
    </div>
  );
}

const editCellStyle = {
  width: '100%',
  fontFamily: '"JetBrains Mono", monospace',
  fontSize: '13px',
  padding: '6px 8px',
  border: `1.5px solid ${WF_ACCENT}`,
  borderRadius: '2px',
  background: '#fff',
  boxSizing: 'border-box',
};

function OptC_HeaderRow() {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'center',
      background: WF_PAPER,
      borderBottom: `2px solid ${WF_LINE}`,
      fontFamily: '"Kalam", cursive',
      fontSize: '10px',
      color: WF_MUTED,
      textTransform: 'uppercase',
      letterSpacing: '0.08em',
      fontWeight: 600,
    }}>
      <div style={{ width: '36px', padding: '10px 6px', borderRight: `1px solid ${WF_LINE}22` }}></div>
      <div style={{ width: '170px', padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>contract / delivery</div>
      <div style={{ width: '110px', padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>posted bid</div>
      <div style={{ width: '100px', padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>max bid</div>
      <div style={{ width: '90px', padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>leeway</div>
      <div style={{ width: '100px', padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>bid incr.</div>
      <div style={{ flex: 1, padding: '10px 12px', borderRight: `1px solid ${WF_LINE}22` }}>last updated</div>
      <div style={{ padding: '10px 12px', minWidth: '140px', textAlign: 'center' }}>actions</div>
    </div>
  );
}

function OptionC() {
  const [expanded, setExpanded] = React.useState(new Set(['Z26', 'N26']));
  const [editing, setEditing] = React.useState(new Set(['Z26-A']));

  const toggle = (code) => {
    const next = new Set(expanded);
    if (next.has(code)) next.delete(code); else next.add(code);
    setExpanded(next);
  };
  const toggleEdit = (code) => {
    const next = new Set(editing);
    if (next.has(code)) next.delete(code); else next.add(code);
    setEditing(next);
  };

  return (
    <div style={{ width: '100%', height: '100%', background: WF_BG, display: 'flex', flexDirection: 'column' }}>
      <WfTopBar subtitle="spreadsheet · inline + full-page revise" />

      {/* Batch edit toolbar */}
      <div style={{
        padding: '8px 16px',
        background: WF_PAPER,
        borderBottom: `1px solid ${WF_LINE}`,
        display: 'flex', gap: '8px', alignItems: 'center',
      }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '12px', color: WF_MUTED }}>
          showing 9 contracts · {expanded.size} expanded
        </div>
        <div style={{ flex: 1 }} />
        <WfBtn small>shift all posted ±</WfBtn>
        <WfBtn small>expand all</WfBtn>
        <WfBtn small>collapse all</WfBtn>
        <WfBtn small primary>＋ add</WfBtn>
      </div>

      <div style={{ flex: 1, overflow: 'auto' }}>
        <OptC_HeaderRow />
        {CORN_CONTRACTS.map(c => (
          <React.Fragment key={c.code}>
            <OptC_ParentRow
              contract={c}
              expanded={expanded.has(c.code)}
              onToggle={() => toggle(c.code)}
              onRevise={() => {}}
            />
            {expanded.has(c.code) && (DELIVERY_WINDOWS[c.code] || []).map(w => (
              <OptC_ChildRow
                key={w.code}
                window={w}
                parentCode={c.code}
                editing={editing.has(w.code)}
                onToggleEdit={() => toggleEdit(w.code)}
              />
            ))}
          </React.Fragment>
        ))}
      </div>

      {/* Footer editing banner */}
      {editing.size > 0 && (
        <div style={{
          padding: '10px 18px',
          background: WF_ACCENT,
          color: '#fff',
          display: 'flex', alignItems: 'center', gap: '12px',
          fontFamily: '"Kalam", cursive', fontSize: '13px',
        }}>
          <span>✎ editing {editing.size} window{editing.size > 1 ? 's' : ''} inline</span>
          <div style={{ flex: 1 }} />
          <WfBtn small style={{ border: '1.5px solid #fff', color: '#fff' }} onClick={() => setEditing(new Set())}>discard</WfBtn>
          <WfBtn small style={{ background: '#fff', color: WF_ACCENT, border: '1.5px solid #fff' }}>save all</WfBtn>
        </div>
      )}
    </div>
  );
}

window.OptionC = OptionC;
