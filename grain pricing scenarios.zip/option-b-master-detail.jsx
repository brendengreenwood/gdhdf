// Option B — Master list + dedicated edit page
// Left: compact list of all 9 futures contracts. Right: the selected contract's
// detail view. Clicking "revise" swaps the detail panel into full edit mode
// (dedicated page, not a modal) showing parent config + every forward window
// editable in one place.

function OptB_ListItem({ contract, selected, onClick }) {
  const p = PRICING_DATA[contract.code];
  const windowCount = (DELIVERY_WINDOWS[contract.code] || []).length;
  return (
    <div
      onClick={onClick}
      style={{
        padding: '10px 14px',
        borderLeft: `3px solid ${selected ? WF_ACCENT : 'transparent'}`,
        background: selected ? WF_PAPER : 'transparent',
        borderBottom: `1px solid ${WF_LINE}22`,
        cursor: 'pointer',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', gap: '6px' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '15px', fontWeight: 700, whiteSpace: 'nowrap' }}>
          {contract.label}
        </div>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
          {contract.code}
        </div>
      </div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginTop: '2px' }}>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '14px', fontWeight: 600, color: WF_RED }}>
          {formatBasis(p.posted)}
        </div>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED }}>
          {windowCount} windows
        </div>
      </div>
    </div>
  );
}

function OptB_Detail({ contract }) {
  const p = PRICING_DATA[contract.code];
  const windows = DELIVERY_WINDOWS[contract.code] || [];
  return (
    <div style={{ padding: '24px 28px', height: '100%', overflowY: 'auto' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '26px', fontWeight: 700 }}>
            {contract.label}
          </div>
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', color: WF_MUTED, marginTop: '2px' }}>
            CBOT Corn · ZC{contract.code} · updated {p.updated} by {p.by}
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <WfBtn>view history</WfBtn>
          <WfBtn primary>revise →</WfBtn>
        </div>
      </div>
      <Underline width={260} />

      {/* Parent pricing card */}
      <div style={{ ...wfBoxPaper, marginTop: '20px', padding: '16px 18px' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '14px', fontWeight: 700 }}>
            Parent pricing config
          </div>
          <WfPill color={WF_ACCENT} filled>active</WfPill>
        </div>
        <div style={{ display: 'flex', gap: '28px' }}>
          <WfField label="posted bid" value={formatBasis(p.posted)} emphasis />
          <WfField label="max bid" value={formatBasis(p.max)} />
          <WfField label="leeway" value={`${p.leeway}¢`} />
          <WfField label="increment" value={`${p.increment}¢`} />
        </div>
      </div>

      {/* Forward windows list */}
      <div style={{ marginTop: '22px' }}>
        <div style={{
          display: 'flex', alignItems: 'center', justifyContent: 'space-between',
          marginBottom: '10px',
        }}>
          <div>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '15px', fontWeight: 700 }}>
              Forward delivery windows
            </div>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED }}>
              {windows.length} half-month windows mapped to {contract.code}
            </div>
          </div>
          <WfBtn small>＋ add window</WfBtn>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', fontFamily: '"JetBrains Mono", monospace', fontSize: '13px' }}>
          <thead>
            <tr style={{ borderBottom: `1.5px solid ${WF_LINE}` }}>
              <th style={thStyle}>delivery</th>
              <th style={thStyle}>source</th>
              <th style={thStyle}>posted</th>
              <th style={thStyle}>max</th>
              <th style={thStyle}>leeway</th>
              <th style={thStyle}>incr.</th>
              <th style={thStyle}></th>
            </tr>
          </thead>
          <tbody>
            {windows.map(w => {
              const wp = getWindowPricing(contract.code, w.code);
              return (
                <tr key={w.code} style={{ borderBottom: `1px dashed ${WF_MUTED}66` }}>
                  <td style={tdStyle}>
                    <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 600 }}>
                      {w.label}
                    </div>
                  </td>
                  <td style={tdStyle}>
                    {wp.isOverride
                      ? <WfPill color={WF_ACCENT}>override</WfPill>
                      : <span style={{ color: WF_MUTED, fontSize: '11px' }}>inherits parent</span>}
                  </td>
                  <td style={{ ...tdStyle, color: wp.isOverride ? WF_RED : WF_INK, fontWeight: 600 }}>
                    {formatBasis(wp.posted)}
                  </td>
                  <td style={tdStyle}>{formatBasis(wp.max)}</td>
                  <td style={tdStyle}>{wp.leeway}¢</td>
                  <td style={tdStyle}>{wp.increment}¢</td>
                  <td style={{ ...tdStyle, textAlign: 'right' }}>
                    <WfBtn small>view</WfBtn>
                    {' '}
                    <WfBtn small>revise</WfBtn>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

const thStyle = {
  textAlign: 'left',
  padding: '8px 10px',
  fontFamily: '"Kalam", cursive',
  fontSize: '10px',
  color: WF_MUTED,
  textTransform: 'uppercase',
  letterSpacing: '0.06em',
  fontWeight: 600,
};
const tdStyle = {
  padding: '10px',
  verticalAlign: 'middle',
};

function OptionB() {
  const [selected, setSelected] = React.useState(CORN_CONTRACTS[3]); // Z26

  return (
    <div style={{ width: '100%', height: '100%', background: WF_BG, display: 'flex', flexDirection: 'column' }}>
      <WfTopBar subtitle="master list · detail page" />
      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        {/* Left master list */}
        <div style={{ width: '240px', borderRight: `1.5px solid ${WF_LINE}`, overflowY: 'auto', background: WF_BG }}>
          <div style={{ padding: '10px 14px', fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', borderBottom: `1px solid ${WF_LINE}44` }}>
            corn contracts · 9
          </div>
          {CORN_CONTRACTS.map(c => (
            <OptB_ListItem
              key={c.code}
              contract={c}
              selected={selected.code === c.code}
              onClick={() => setSelected(c)}
            />
          ))}
        </div>
        {/* Right detail */}
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <OptB_Detail contract={selected} />
        </div>
      </div>
    </div>
  );
}

window.OptionB = OptionB;
