// Option A — Table with expanding rows (no accordion cards)
// Single unified table. Futures contracts are the primary rows; clicking a row
// expands nested delivery-window rows beneath. Revise = slide-out side panel.

function OptA_ParentRow({ contract, expanded, onToggle, onRevise, density, showUpdated, showCode }) {
  const p = PRICING_DATA[contract.code];
  const windowCount = (DELIVERY_WINDOWS[contract.code] || []).length;
  const hasWindows = windowCount > 0;
  const pad = density === 'compact' ? '6px 10px' : density === 'roomy' ? '16px 14px' : '11px 12px';
  return (
    <tr
      onClick={hasWindows ? onToggle : undefined}
      style={{
        cursor: hasWindows ? 'pointer' : 'default',
        background: expanded ? WF_PAPER : (contract._zebra ? '#f7f4ec' : WF_BG),
        borderBottom: `1.5px solid ${WF_LINE}`,
      }}
    >
      <td style={{ padding: pad, width: '32px', textAlign: 'center', fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', color: hasWindows ? WF_INK : WF_MUTED + '55' }}>
        {hasWindows ? (expanded ? '▾' : '▸') : '–'}
      </td>
      <td style={{ padding: pad, minWidth: '160px' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '16px', fontWeight: 700, whiteSpace: 'nowrap' }}>
          {contract.label}
        </div>
        {showCode && (
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
            ZC · {contract.code} {hasWindows ? `· ${windowCount} windows` : '· no delivery windows'}
          </div>
        )}
      </td>
      <td style={{ padding: pad, fontFamily: '"JetBrains Mono", monospace', fontSize: '15px', fontWeight: 700, color: WF_RED, whiteSpace: 'nowrap' }}>
        {formatBasis(p.posted)}
      </td>
      <td style={{ padding: pad, fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', whiteSpace: 'nowrap' }}>
        {formatBasis(p.max)}
      </td>
      <td style={{ padding: pad, fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', whiteSpace: 'nowrap' }}>
        {p.leeway}¢
      </td>
      <td style={{ padding: pad, fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', whiteSpace: 'nowrap' }}>
        {p.increment}¢
      </td>
      <td style={{ padding: pad, fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', whiteSpace: 'nowrap' }}>
        ${p.freight != null ? p.freight.toFixed(2) : '0.45'}/mi
      </td>
      {showUpdated && (
        <td style={{ padding: pad, fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
          <div>{p.updated}</div>
          <div style={{ color: WF_INK }}>by {p.by}</div>
        </td>
      )}
      <td style={{ padding: pad, textAlign: 'right', whiteSpace: 'nowrap' }} onClick={(e) => e.stopPropagation()}>
        <WfBtn small>view</WfBtn>{' '}
        <WfBtn small>＋ TOS</WfBtn>{' '}
        <WfBtn small primary onClick={onRevise}>revise</WfBtn>
      </td>
    </tr>
  );
}

function OptA_ChildRow({ window: w, parentCode, density, showUpdated, showCode }) {
  const wp = getWindowPricing(parentCode, w.code);
  const pad = density === 'compact' ? '5px 10px 5px 44px' : density === 'roomy' ? '12px 14px 12px 48px' : '8px 12px 8px 46px';
  const cellPad = density === 'compact' ? '5px 10px' : density === 'roomy' ? '12px 14px' : '8px 12px';
  return (
    <tr style={{
      background: WF_BG,
      borderBottom: `1px dashed ${WF_MUTED}66`,
    }}>
      <td style={{ padding: cellPad, width: '32px', textAlign: 'center', color: WF_MUTED, fontSize: '12px' }}>
        ↳
      </td>
      <td style={{ padding: pad, borderLeft: `3px solid ${wp.isOverride ? WF_ACCENT : 'transparent'}` }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 600, whiteSpace: 'nowrap' }}>
          {w.label}
        </div>
        {showCode && (
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '9px', color: wp.isOverride ? WF_ACCENT : WF_MUTED, whiteSpace: 'nowrap' }}>
            {w.code} · {wp.isOverride ? '⚑ override' : '↳ inherits parent'}
          </div>
        )}
      </td>
      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', fontWeight: wp.isOverride ? 700 : 500, color: wp.isOverride ? WF_ACCENT : WF_MUTED, whiteSpace: 'nowrap' }}>
        {formatBasis(wp.posted)}
      </td>
      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '12px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
        {formatBasis(wp.max)}
      </td>
      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '12px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
        {wp.leeway}¢
      </td>
      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '12px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
        {wp.increment}¢
      </td>
      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '12px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
        ${(wp.freight != null ? wp.freight : 0.45).toFixed(2)}/mi
      </td>
      {showUpdated && (
        <td style={{ padding: cellPad, fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED, whiteSpace: 'nowrap' }}>
          {wp.isOverride ? 'custom' : '— parent —'}
        </td>
      )}
      <td style={{ padding: cellPad, textAlign: 'right', whiteSpace: 'nowrap' }}>
        <WfBtn small>view</WfBtn>{' '}
        <WfBtn small>revise</WfBtn>
      </td>
    </tr>
  );
}

function OptA_RevisePanel({ contract, onClose }) {
  const p = PRICING_DATA[contract.code];
  return (
    <div style={{
      position: 'absolute', top: 0, right: 0, bottom: 0,
      width: '520px', background: WF_BG,
      borderLeft: `2px solid ${WF_LINE}`,
      boxShadow: '-4px 0 12px rgba(0,0,0,0.08)',
      padding: '20px 24px',
      overflowY: 'auto',
      zIndex: 20,
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '20px', fontWeight: 700 }}>
            Revise · {contract.label}
          </div>
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>
            ZC {contract.code} · applies to {(DELIVERY_WINDOWS[contract.code] || []).length} delivery windows
          </div>
        </div>
        <WfBtn small onClick={onClose}>× close</WfBtn>
      </div>
      <Underline width={200} />

      <div style={{ marginTop: '20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '14px' }}>
        {[
          ['posted bid (basis)', `${p.posted}¢`],
          ['max bid (basis)', `${p.max}¢`],
          ['price leeway', `${p.leeway}¢`],
          ['bid increment', `${p.increment}¢`],
        ].map(([label, val]) => (
          <div key={label}>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase' }}>
              {label}
            </div>
            <input defaultValue={val} style={{
              marginTop: '4px',
              width: '100%',
              fontFamily: '"JetBrains Mono", monospace',
              fontSize: '16px',
              padding: '8px 10px',
              border: `1.5px solid ${WF_LINE}`,
              borderRadius: '2px',
              background: WF_PAPER,
            }} />
          </div>
        ))}
      </div>

      <div style={{ marginTop: '22px' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 700, marginBottom: '6px' }}>
          Apply to forward delivery windows?
        </div>
        {(DELIVERY_WINDOWS[contract.code] || []).map((w, i) => (
          <label key={w.code} style={{
            display: 'flex', alignItems: 'center', gap: '10px',
            padding: '6px 0',
            fontFamily: '"Kalam", cursive', fontSize: '13px',
          }}>
            <input type="checkbox" defaultChecked={i !== 0} />
            <span style={{ minWidth: '160px' }}>{w.label}</span>
            <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>
              {i === 0 ? 'override (keep)' : 'inherit new values'}
            </span>
          </label>
        ))}
      </div>

      <div style={{ marginTop: '18px' }}>
        <WfPlaceholder h={60} label="preview: resulting flat prices" />
      </div>

      <div style={{ marginTop: '22px', display: 'flex', gap: '10px', justifyContent: 'flex-end' }}>
        <WfBtn onClick={onClose}>cancel</WfBtn>
        <WfBtn primary>save & publish</WfBtn>
      </div>
    </div>
  );
}

// AppRail — left-side navigation rail for the OptionA app shell
function OptA_AppRail({ active }) {
  const [open, setOpen] = React.useState(false);
  const items = [
    { id: 'scenarios',  label: 'Scenarios',  icon: '▤', active: active === 'scenarios' },
    { id: 'producers',  label: 'Producers',  icon: '◍' },
    { id: 'competitors', label: 'Competitors', icon: '◈' },
  ];
  return (
    <div style={{
      width: open ? '180px' : '52px',
      transition: 'width 180ms ease',
      background: '#1a1a1a',
      color: '#fafaf7',
      borderRight: `1.5px solid ${WF_LINE}`,
      display: 'flex', flexDirection: 'column',
      flexShrink: 0,
      height: '100%',
      overflow: 'hidden',
    }}>
      <div style={{
        padding: open ? '18px 18px 14px' : '18px 0 14px',
        borderBottom: `1px solid #ffffff20`,
        display: 'flex', alignItems: 'center', justifyContent: open ? 'space-between' : 'center',
        gap: '8px',
      }}>
        {open ? (
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '20px', fontWeight: 700, color: '#fafaf7' }}>
            Kernel
          </div>
        ) : (
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '18px', fontWeight: 700, color: WF_ACCENT }}>
            K
          </div>
        )}
        {open && (
          <button onClick={() => setOpen(false)} title="collapse" style={{
            background: 'transparent', border: 'none', color: '#ffffff80',
            cursor: 'pointer', fontFamily: '"Kalam", cursive', fontSize: '16px',
            padding: '0 2px', lineHeight: 1,
          }}>‹</button>
        )}
      </div>
      <nav style={{ padding: '12px 8px', display: 'flex', flexDirection: 'column', gap: '2px' }}>
        {items.map(it => (
          <a key={it.id} href="#" onClick={(e) => e.preventDefault()} title={open ? null : it.label} style={{
            display: 'flex', alignItems: 'center', gap: '12px',
            padding: open ? '9px 12px' : '10px 0',
            justifyContent: open ? 'flex-start' : 'center',
            fontFamily: '"Kalam", cursive', fontSize: '14px',
            color: it.active ? '#1a1a1a' : '#fafaf7',
            background: it.active ? WF_ACCENT : 'transparent',
            borderRadius: '3px',
            textDecoration: 'none',
            fontWeight: it.active ? 700 : 500,
          }}>
            <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '14px', width: '16px', textAlign: 'center' }}>{it.icon}</span>
            {open && <span>{it.label}</span>}
          </a>
        ))}
      </nav>
      <div style={{ flex: 1 }} />
      {!open && (
        <button onClick={() => setOpen(true)} title="expand" style={{
          background: 'transparent', border: 'none', color: '#ffffff80',
          cursor: 'pointer', fontFamily: '"Kalam", cursive', fontSize: '16px',
          padding: '12px 0', lineHeight: 1,
          borderTop: `1px solid #ffffff20`,
        }}>›</button>
      )}
    </div>
  );
}

function OptA_TabBar({ tabs, active, onChange, primary }) {
  return (
    <div style={{
      display: 'flex',
      gap: primary ? '0' : '0',
      padding: primary ? '0 20px' : '0 20px',
      background: primary ? WF_PAPER : WF_BG,
      borderBottom: primary ? `1.5px solid ${WF_LINE}` : `1px solid ${WF_LINE}33`,
    }}>
      {tabs.map(t => {
        const isActive = t.id === active;
        return (
          <button
            key={t.id}
            onClick={() => onChange && onChange(t.id)}
            style={{
              fontFamily: '"Kalam", cursive',
              fontSize: primary ? '14px' : '13px',
              fontWeight: isActive ? 700 : 500,
              padding: primary ? '12px 18px' : '8px 14px',
              border: 'none',
              borderBottom: isActive
                ? `${primary ? '3px' : '2px'} solid ${WF_ACCENT}`
                : `${primary ? '3px' : '2px'} solid transparent`,
              background: 'transparent',
              color: isActive ? WF_INK : WF_MUTED,
              cursor: 'pointer',
              marginBottom: '-1.5px',
              whiteSpace: 'nowrap',
            }}
          >
            {t.label}
            {t.count !== undefined && (
              <span style={{
                fontFamily: '"JetBrains Mono", monospace',
                fontSize: '10px',
                marginLeft: '6px',
                color: isActive ? WF_ACCENT : WF_MUTED,
                fontWeight: 500,
              }}>
                {t.count}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

function OptionA(props) {
  const density = props.density || 'balanced';
  const showUpdated = props.showUpdated !== false;
  const showCode = props.showCode !== false;
  const zebra = !!props.zebra;

  const [expanded, setExpanded] = React.useState(new Set(['N26']));
  const [revising, setRevising] = React.useState(null);
  const [activeElevator, setActiveElevator] = React.useState('all');
  const [activeCommodity, setActiveCommodity] = React.useState('corn');

  const elevatorTabs = [
    { id: 'all', label: 'All elevators', count: 2 },
    { id: 'sidney', label: 'Sidney, OH' },
    { id: 'lima', label: 'Lima, OH' },
  ];
  const commodityTabs = [
    { id: 'corn', label: 'Corn', count: 3 },
    { id: 'soybeans', label: 'Soybeans' },
    { id: 'wheat', label: 'Wheat' },
  ];

  const toggle = (code) => {
    const next = new Set(expanded);
    if (next.has(code)) next.delete(code); else next.add(code);
    setExpanded(next);
  };

  const headPad = density === 'compact' ? '6px 10px' : density === 'roomy' ? '12px 14px' : '9px 12px';
  const thStyle = {
    padding: headPad,
    textAlign: 'left',
    fontFamily: '"Kalam", cursive',
    fontSize: '10px',
    color: WF_MUTED,
    textTransform: 'uppercase',
    letterSpacing: '0.07em',
    fontWeight: 600,
    borderBottom: `2px solid ${WF_LINE}`,
    background: WF_PAPER,
    whiteSpace: 'nowrap',
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden', background: WF_BG, display: 'flex' }}>
      <OptA_AppRail active="scenarios" />
      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <WfTopBar
        title="Scenarios"
        right={<WfBtn small primary>＋ new scenario</WfBtn>}
      />

      <OptA_TabBar tabs={elevatorTabs} active={activeElevator} onChange={setActiveElevator} primary />
      <OptA_TabBar tabs={commodityTabs} active={activeCommodity} onChange={setActiveCommodity} />

      <div style={{ padding: '0', flex: 1, overflowY: 'auto' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'auto' }}>
          <thead style={{ position: 'sticky', top: 0, zIndex: 2 }}>
            <tr>
              <th style={{ ...thStyle, width: '32px', padding: '4px 0', textAlign: 'center' }}>
                {(() => {
                  const expandableCodes = CORN_CONTRACTS
                    .filter(c => (DELIVERY_WINDOWS[c.code] || []).length > 0)
                    .map(c => c.code);
                  const allExpanded = expandableCodes.length > 0 && expandableCodes.every(code => expanded.has(code));
                  return (
                    <button
                      onClick={() => setExpanded(allExpanded ? new Set() : new Set(expandableCodes))}
                      title={allExpanded ? 'collapse all' : 'expand all'}
                      style={{
                        background: 'transparent',
                        border: `1.2px solid ${WF_LINE}`,
                        borderRadius: '2px',
                        width: '22px', height: '22px',
                        fontFamily: '"JetBrains Mono", monospace',
                        fontSize: '12px',
                        cursor: 'pointer',
                        color: WF_INK,
                        display: 'inline-flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                      }}
                    >
                      {allExpanded ? '−' : '+'}
                    </button>
                  );
                })()}
              </th>
              <th style={thStyle}>contract / delivery window</th>
              <th style={thStyle}>posted bid</th>
              <th style={thStyle}>max bid</th>
              <th style={thStyle}>leeway</th>
              <th style={thStyle}>bid incr.</th>
              <th style={thStyle}>freight</th>
              {showUpdated && <th style={thStyle}>last updated</th>}
              <th style={{ ...thStyle, textAlign: 'right' }}>actions</th>
            </tr>
          </thead>
          <tbody>
            {CORN_CONTRACTS.map((c, i) => {
              const contractWithZebra = { ...c, _zebra: zebra && i % 2 === 1 };
              const isExpanded = expanded.has(c.code);
              return (
                <React.Fragment key={c.code}>
                  <OptA_ParentRow
                    contract={contractWithZebra}
                    expanded={isExpanded}
                    onToggle={() => toggle(c.code)}
                    onRevise={() => setRevising(c)}
                    density={density}
                    showUpdated={showUpdated}
                    showCode={showCode}
                  />
                  {isExpanded && (DELIVERY_WINDOWS[c.code] || []).map(w => (
                    <OptA_ChildRow
                      key={w.code}
                      window={w}
                      parentCode={c.code}
                      density={density}
                      showUpdated={showUpdated}
                      showCode={showCode}
                    />
                  ))}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>
      </div>

      {revising && <OptA_RevisePanel contract={revising} onClose={() => setRevising(null)} />}
      </div>
    </div>
  );
}

window.OptionA = OptionA;
window.OptA_AppRail = OptA_AppRail;
