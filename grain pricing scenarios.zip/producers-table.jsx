// Producers table view — originator's outbound queue + lookup
// Wireframe-fidelity. Lives at app rail item: Producers.

(function () {

const PROD_INK = '#1a1a1a';
const PROD_BG = '#fafaf7';
const PROD_PAPER = '#fffdf7';
const PROD_LINE = '#1a1a1a';
const PROD_MUTED = '#6a5a3a';
const PROD_ACCENT = '#d97706';

// ---------- Mock producer data ----------

const PRODUCERS = [
  { id: 'p01', biz: 'Thornton Family Farms LLC',   farmer: 'Jamie Thornton',   elev: 'Sidney, OH', commodities: ['corn','beans'],         lastSpot: '2026-04-12', lastDelivery: '2026-03-28', lastContact: '2026-04-22', activeBids: 3, opportunity: 4200, dist: 18, score: 92 },
  { id: 'p02', biz: 'Wexler Grain Co',              farmer: 'Sara Wexler',      elev: 'Sidney, OH', commodities: ['corn'],                  lastSpot: '2026-04-09', lastDelivery: '2026-04-02', lastContact: '2026-04-19', activeBids: 2, opportunity: 3100, dist: 24, score: 88 },
  { id: 'p03', biz: 'Holcomb Bros Inc',             farmer: 'Ray Holcomb',      elev: 'Lima, OH',   commodities: ['corn','beans','wheat'],  lastSpot: '2026-04-15', lastDelivery: '2026-04-10', lastContact: '2026-04-25', activeBids: 4, opportunity: 5800, dist: 12, score: 95 },
  { id: 'p04', biz: 'Pell Acres',                    farmer: 'Marcus Pell',      elev: 'Sidney, OH', commodities: ['beans'],                 lastSpot: '2026-03-30', lastDelivery: '2026-03-15', lastContact: '2026-04-05', activeBids: 1, opportunity: 1900, dist: 31, score: 71 },
  { id: 'p05', biz: 'Burdick Farms',                 farmer: 'Lisa Burdick',     elev: 'Sidney, OH', commodities: ['corn','beans'],         lastSpot: '2026-04-11', lastDelivery: '2026-03-22', lastContact: '2026-04-18', activeBids: 2, opportunity: 2400, dist: 22, score: 84 },
  { id: 'p06', biz: 'Nakamura Family Trust',         farmer: 'Dan Nakamura',     elev: 'Lima, OH',   commodities: ['corn'],                  lastSpot: '2026-04-08', lastDelivery: '2026-04-01', lastContact: '2026-03-28', activeBids: 0, opportunity: 3600, dist: 16, score: 79 },
  { id: 'p07', biz: 'Kovach Ag',                     farmer: 'Emily Kovach',     elev: 'Sidney, OH', commodities: ['corn','wheat'],         lastSpot: '2026-04-14', lastDelivery: '2026-04-08', lastContact: '2026-04-20', activeBids: 3, opportunity: 4900, dist: 19, score: 90 },
  { id: 'p08', biz: 'Reilly Farms LLC',              farmer: 'Tom Reilly',       elev: 'Lima, OH',   commodities: ['corn','beans'],         lastSpot: '2026-04-13', lastDelivery: '2026-03-30', lastContact: '2026-04-23', activeBids: 2, opportunity: 2700, dist: 27, score: 82 },
  { id: 'p09', biz: 'Vance Grain Partners',          farmer: 'Carla Vance',      elev: 'Sidney, OH', commodities: ['beans'],                 lastSpot: '2026-04-07', lastDelivery: '2026-03-19', lastContact: '2026-04-12', activeBids: 1, opportunity: 1400, dist: 35, score: 68 },
  { id: 'p10', biz: 'Olson Family Farm',             farmer: 'Pat Olson',        elev: 'Sidney, OH', commodities: ['corn','beans','wheat'], lastSpot: '2026-04-16', lastDelivery: '2026-04-12', lastContact: '2026-04-26', activeBids: 4, opportunity: 6200, dist: 14, score: 96 },
  { id: 'p11', biz: 'Wahl Acres Inc',                farmer: 'Greg Wahl',        elev: 'Lima, OH',   commodities: ['corn'],                  lastSpot: '2026-04-10', lastDelivery: '2026-03-25', lastContact: '2026-04-15', activeBids: 2, opportunity: 2100, dist: 29, score: 76 },
  { id: 'p12', biz: 'Harlow Farms',                  farmer: 'Jess Harlow',      elev: 'Sidney, OH', commodities: ['corn','beans'],         lastSpot: '2026-03-22', lastDelivery: '2026-03-08', lastContact: '2026-03-15', activeBids: 0, opportunity: 800,  dist: 41, score: 54 },
  { id: 'p13', biz: 'Crenshaw & Sons Grain',         farmer: 'Bill Crenshaw',    elev: 'Lima, OH',   commodities: ['corn','beans'],         lastSpot: '2026-04-12', lastDelivery: '2026-04-04', lastContact: '2026-04-21', activeBids: 3, opportunity: 3300, dist: 17, score: 86 },
  { id: 'p14', biz: 'Mendez Ranch',                  farmer: 'Rosa Mendez',      elev: 'Sidney, OH', commodities: ['corn'],                  lastSpot: '2026-04-06', lastDelivery: '2026-03-12', lastContact: '2026-04-08', activeBids: 1, opportunity: 1700, dist: 33, score: 72 },
  { id: 'p15', biz: 'Patterson Family Farms',        farmer: 'Hank Patterson',   elev: 'Lima, OH',   commodities: ['beans','wheat'],        lastSpot: '2026-04-14', lastDelivery: '2026-04-09', lastContact: '2026-04-24', activeBids: 2, opportunity: 2900, dist: 21, score: 83 },
  { id: 'p16', biz: 'Greer Grain Holdings',          farmer: 'Diane Greer',      elev: 'Sidney, OH', commodities: ['corn','beans'],         lastSpot: '2026-04-15', lastDelivery: '2026-04-11', lastContact: '2026-04-25', activeBids: 4, opportunity: 5400, dist: 15, score: 93 },
  { id: 'p17', biz: 'Albright Acres',                farmer: 'Carl Albright',    elev: 'Lima, OH',   commodities: ['corn'],                  lastSpot: '2026-04-04', lastDelivery: '2026-03-18', lastContact: '2026-04-01', activeBids: 0, opportunity: 2200, dist: 25, score: 70 },
  { id: 'p18', biz: 'Boucher Farms LLC',             farmer: 'Pierre Boucher',   elev: 'Sidney, OH', commodities: ['corn','beans','wheat'], lastSpot: '2026-04-13', lastDelivery: '2026-04-06', lastContact: '2026-04-22', activeBids: 3, opportunity: 4100, dist: 20, score: 89 },
  { id: 'p19', biz: 'Sutton Brothers Farm',          farmer: 'Earl Sutton',      elev: 'Lima, OH',   commodities: ['beans'],                 lastSpot: '2026-04-02', lastDelivery: '2026-03-10', lastContact: '2026-04-03', activeBids: 1, opportunity: 1200, dist: 38, score: 62 },
  { id: 'p20', biz: 'Quintero Ag',                   farmer: 'Maria Quintero',   elev: 'Sidney, OH', commodities: ['corn','beans'],         lastSpot: '2026-04-11', lastDelivery: '2026-03-29', lastContact: '2026-04-17', activeBids: 2, opportunity: 2600, dist: 23, score: 81 },
  { id: 'p21', biz: 'Velasquez Farms',               farmer: 'Nico Velasquez',   elev: 'Lima, OH',   commodities: ['corn','beans'],         lastSpot: '2026-04-09', lastDelivery: '2026-04-03', lastContact: '2026-04-16', activeBids: 2, opportunity: 3000, dist: 18, score: 85 },
  { id: 'p22', biz: 'Kowalski Family Grain',         farmer: 'Ed Kowalski',      elev: 'Sidney, OH', commodities: ['corn'],                  lastSpot: '2026-04-08', lastDelivery: '2026-03-21', lastContact: '2026-04-11', activeBids: 1, opportunity: 1600, dist: 30, score: 73 },
  { id: 'p23', biz: 'Brennan Acres',                 farmer: 'Liam Brennan',     elev: 'Lima, OH',   commodities: ['corn','wheat'],         lastSpot: '2026-04-12', lastDelivery: '2026-04-07', lastContact: '2026-04-23', activeBids: 3, opportunity: 3700, dist: 19, score: 87 },
  { id: 'p24', biz: 'Doyle Grain Inc',               farmer: 'Maeve Doyle',      elev: 'Sidney, OH', commodities: ['corn','beans'],         lastSpot: '2026-04-15', lastDelivery: '2026-04-13', lastContact: '2026-04-26', activeBids: 4, opportunity: 5100, dist: 13, score: 91 },
];

// ---------- Helpers ----------

function fmtDate(s) {
  if (!s) return '—';
  const d = new Date(s + 'T12:00:00');
  return d.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
}
function daysSince(s) {
  if (!s) return 999;
  const today = new Date('2026-04-29T12:00:00');
  const d = new Date(s + 'T12:00:00');
  return Math.round((today - d) / 86400000);
}

// ---------- FilterChip ----------

function ProdChip({ label, value, onClear }) {
  return (
    <div style={{
      display: 'inline-flex', alignItems: 'center', gap: '6px',
      padding: '4px 4px 4px 10px',
      border: `1.2px solid ${PROD_LINE}`,
      borderRadius: '2px',
      background: PROD_PAPER,
      fontFamily: '"Kalam", cursive', fontSize: '12px',
      whiteSpace: 'nowrap',
    }}>
      <span style={{ color: PROD_MUTED, fontSize: '10px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}:</span>
      <span style={{ fontWeight: 600 }}>{value}</span>
      <button onClick={onClear} title="clear" style={{
        background: 'transparent', border: 'none', cursor: 'pointer',
        fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', color: PROD_MUTED,
        padding: '0 4px', lineHeight: 1,
      }}>×</button>
    </div>
  );
}

function ProdFilterDropdown({ label, children }) {
  return (
    <button style={{
      display: 'inline-flex', alignItems: 'center', gap: '6px',
      padding: '4px 8px',
      border: `1.2px dashed ${PROD_MUTED}`,
      borderRadius: '2px',
      background: 'transparent',
      fontFamily: '"Kalam", cursive', fontSize: '12px',
      color: PROD_MUTED,
      cursor: 'pointer',
      whiteSpace: 'nowrap',
    }}>
      ＋ {label}
    </button>
  );
}

// ---------- Top-N call queue panel ----------

function ProdCallQueue({ producers, onPick, openId, side = 'right' }) {
  const top = [...producers].sort((a,b) => b.score - a.score).slice(0, 8);
  return (
    <div style={{
      width: '300px',
      borderLeft: side === 'right' ? `1.5px solid ${PROD_LINE}` : 'none',
      borderRight: side === 'left' ? `1.5px solid ${PROD_LINE}` : 'none',
      background: PROD_PAPER,
      display: 'flex', flexDirection: 'column',
      flexShrink: 0,
      overflow: 'hidden',
    }}>
      <div style={{ padding: '14px 18px 10px', borderBottom: `1px dashed ${PROD_MUTED}` }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '14px', fontWeight: 700, marginBottom: '2px' }}>
          Top to contact
        </div>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '10px', color: PROD_MUTED, lineHeight: 1.4 }}>
          ranked by opportunity × days since contact × active bid delta
        </div>
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {top.map((p, i) => {
          const isOpen = p.id === openId;
          return (
            <button key={p.id} onClick={() => onPick(p)} style={{
              width: '100%', textAlign: 'left',
              padding: '10px 18px',
              background: isOpen ? PROD_ACCENT + '18' : 'transparent',
              border: 'none',
              borderBottom: `1px dashed ${PROD_MUTED}33`,
              cursor: 'pointer',
              display: 'flex', alignItems: 'flex-start', gap: '10px',
            }}>
              <div style={{
                width: '22px', height: '22px',
                background: PROD_INK, color: '#fafaf7',
                fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', fontWeight: 700,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                flexShrink: 0, marginTop: '1px',
              }}>{i + 1}</div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 700, lineHeight: 1.2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
                  {p.farmer}
                </div>
                <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, lineHeight: 1.3 }}>
                  {p.biz}
                </div>
                <div style={{ display: 'flex', gap: '8px', marginTop: '4px', fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: PROD_MUTED }}>
                  <span>${(p.opportunity / 1000).toFixed(1)}k opp</span>
                  <span>·</span>
                  <span>{daysSince(p.lastContact)}d ago</span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
      <div style={{ padding: '10px 18px', borderTop: `1px dashed ${PROD_MUTED}`, fontFamily: '"Kalam", cursive', fontSize: '10px', color: PROD_MUTED }}>
        ↻ refreshes when scenarios publish
      </div>
    </div>
  );
}

// ---------- Farmer detail drawer ----------

const REJECT_REASONS = [
  'Price too low',
  'Going to competitor',
  'Holding for higher market',
  'Already contracted',
  'Wrong delivery window',
  'Quality concerns',
  'Other',
];

function ProdBidRow({ bid, onUpdate }) {
  const [showHistory, setShowHistory] = React.useState(false);
  const isPending = bid.status === 'pending';
  const isAccepted = bid.status === 'accepted';
  const isRejected = bid.status === 'rejected';

  const statusBadge = (text, color) => (
    <span style={{
      display: 'inline-block',
      padding: '2px 8px',
      fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', fontWeight: 700,
      textTransform: 'uppercase', letterSpacing: '0.05em',
      background: color, color: '#fff',
      borderRadius: '2px',
    }}>{text}</span>
  );

  return (
    <div style={{
      borderBottom: `1px solid ${PROD_LINE}22`,
      padding: '12px 0',
    }}>
      {/* Header row */}
      <div style={{ display: 'flex', alignItems: 'baseline', justifyContent: 'space-between', gap: '10px', marginBottom: '8px' }}>
        <div style={{ display: 'flex', alignItems: 'baseline', gap: '8px' }}>
          <span style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 700 }}>
            {bid.window} · {bid.commodity}
          </span>
          <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '12px', fontWeight: 700 }}>
            {bid.price}
          </span>
          <span style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED }}>
            {bid.offered}k bu offered
          </span>
        </div>
        {isPending && statusBadge('pending', PROD_MUTED)}
        {isAccepted && statusBadge('accepted', '#047857')}
        {isRejected && statusBadge('rejected', '#b91c1c')}
      </div>

      {/* Pending: show outcome controls */}
      {isPending && (
        <div style={{ display: 'flex', gap: '6px', marginBottom: '6px' }}>
          <button onClick={() => onUpdate({ ...bid, status: 'accepted', acceptedBushels: bid.offered })} style={{
            fontFamily: '"Kalam", cursive', fontSize: '12px', fontWeight: 700,
            background: '#047857', color: '#fff',
            border: 'none', padding: '6px 12px', borderRadius: '2px', cursor: 'pointer',
          }}>✓ accept</button>
          <button onClick={() => onUpdate({ ...bid, status: 'rejected', reason: REJECT_REASONS[0] })} style={{
            fontFamily: '"Kalam", cursive', fontSize: '12px', fontWeight: 700,
            background: 'transparent', color: '#b91c1c',
            border: `1.2px solid #b91c1c`, padding: '6px 12px', borderRadius: '2px', cursor: 'pointer',
          }}>✕ reject</button>
          <button style={{
            fontFamily: '"Kalam", cursive', fontSize: '12px',
            background: 'transparent', color: PROD_MUTED,
            border: `1.2px dashed ${PROD_MUTED}`, padding: '6px 12px', borderRadius: '2px', cursor: 'pointer',
          }}>counter</button>
        </div>
      )}

      {/* Accepted: bushels input */}
      {isAccepted && (
        <div style={{
          display: 'flex', alignItems: 'center', gap: '8px',
          padding: '8px 12px',
          background: '#04785712',
          border: `1px solid #04785744`,
          borderRadius: '2px',
        }}>
          <span style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
            bushels accepted
          </span>
          <input
            type="number"
            value={bid.acceptedBushels || 0}
            onChange={(e) => onUpdate({ ...bid, acceptedBushels: Number(e.target.value) })}
            style={{
              width: '90px',
              fontFamily: '"JetBrains Mono", monospace', fontSize: '13px', fontWeight: 700,
              padding: '4px 8px',
              border: `1.2px solid ${PROD_LINE}`,
              borderRadius: '2px',
              background: '#fff',
            }}
          />
          <span style={{ fontFamily: '"Kalam", cursive', fontSize: '12px', color: PROD_MUTED }}>
            of {bid.offered}k offered
            {bid.acceptedBushels !== bid.offered && bid.acceptedBushels > 0 && (
              <span style={{ marginLeft: '6px', color: PROD_ACCENT, fontStyle: 'italic' }}>· partial</span>
            )}
          </span>
          <div style={{ flex: 1 }} />
          <button onClick={() => onUpdate({ ...bid, status: 'pending', acceptedBushels: undefined })} style={{
            fontFamily: '"Kalam", cursive', fontSize: '11px',
            background: 'transparent', color: PROD_MUTED,
            border: 'none', cursor: 'pointer', textDecoration: 'underline',
          }}>undo</button>
        </div>
      )}

      {/* Rejected: reason select */}
      {isRejected && (
        <div style={{
          padding: '8px 12px',
          background: '#b91c1c12',
          border: `1px solid #b91c1c44`,
          borderRadius: '2px',
        }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
            <span style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
              reason
            </span>
            <select
              value={bid.reason || REJECT_REASONS[0]}
              onChange={(e) => onUpdate({ ...bid, reason: e.target.value })}
              style={{
                flex: 1,
                fontFamily: '"Kalam", cursive', fontSize: '13px',
                padding: '4px 8px',
                border: `1.2px solid ${PROD_LINE}`,
                borderRadius: '2px',
                background: '#fff',
              }}
            >
              {REJECT_REASONS.map(r => <option key={r} value={r}>{r}</option>)}
            </select>
            <button onClick={() => onUpdate({ ...bid, status: 'pending', reason: undefined })} style={{
              fontFamily: '"Kalam", cursive', fontSize: '11px',
              background: 'transparent', color: PROD_MUTED,
              border: 'none', cursor: 'pointer', textDecoration: 'underline',
            }}>undo</button>
          </div>
          {bid.reason === 'Going to competitor' && (
            <input
              type="text"
              placeholder="which competitor? (optional)"
              style={{
                width: '100%', marginTop: '6px',
                fontFamily: '"Kalam", cursive', fontSize: '12px',
                padding: '4px 8px',
                border: `1.2px dashed ${PROD_MUTED}`,
                borderRadius: '2px',
                background: 'transparent',
              }}
            />
          )}
          {bid.reason === 'Other' && (
            <input
              type="text"
              placeholder="describe…"
              style={{
                width: '100%', marginTop: '6px',
                fontFamily: '"Kalam", cursive', fontSize: '12px',
                padding: '4px 8px',
                border: `1.2px dashed ${PROD_MUTED}`,
                borderRadius: '2px',
                background: 'transparent',
              }}
            />
          )}
        </div>
      )}

      {/* History toggle */}
      <button onClick={() => setShowHistory(!showHistory)} style={{
        marginTop: '6px',
        fontFamily: '"Kalam", cursive', fontSize: '10px', color: PROD_MUTED,
        background: 'transparent', border: 'none', cursor: 'pointer',
        padding: 0, textDecoration: 'underline',
      }}>
        {showHistory ? '▾' : '▸'} history ({bid.history?.length || 0})
      </button>
      {showHistory && (
        <div style={{ marginTop: '4px', padding: '6px 10px', background: PROD_PAPER, borderLeft: `2px solid ${PROD_MUTED}66`, fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, lineHeight: 1.5 }}>
          {(bid.history || []).map((h, i) => (
            <div key={i}>{h.date} — {h.event}</div>
          ))}
          {(!bid.history || bid.history.length === 0) && <div>no prior events</div>}
        </div>
      )}
    </div>
  );
}

function ProdFarmerDrawer({ farmer, onClose }) {
  if (!farmer) return null;

  // Local bid state — seed from farmer.activeBids count + a couple historical
  const [bids, setBids] = React.useState(() => {
    const windows = ['Jul 1–15', 'Jul 16–31', 'Aug 1–15', 'Sep 1–15'];
    const prices = ['-54¢', '-52¢', '-50¢', '-48¢'];
    const offered = [12, 10, 14, 8];
    const active = Array.from({ length: farmer.activeBids }).map((_, i) => ({
      id: `${farmer.id}-b${i}`,
      window: windows[i], commodity: 'corn',
      price: prices[i], offered: offered[i],
      status: 'pending',
      history: [{ date: 'Apr 22', event: 'bid offered via call' }],
    }));
    // Two historical examples for flavor (only for some farmers)
    const historical = farmer.id < 'p10' ? [
      { id: `${farmer.id}-h1`, window: 'May 1–15', commodity: 'corn', price: '-58¢', offered: 10,
        status: 'accepted', acceptedBushels: 8,
        history: [{ date: 'Mar 28', event: 'bid offered' }, { date: 'Apr 02', event: 'accepted (partial)' }] },
      { id: `${farmer.id}-h2`, window: 'May 16–31', commodity: 'beans', price: '-32¢', offered: 6,
        status: 'rejected', reason: 'Going to competitor',
        history: [{ date: 'Apr 05', event: 'bid offered' }, { date: 'Apr 08', event: 'rejected' }] },
    ] : [];
    return [...active, ...historical];
  });

  React.useEffect(() => {
    // Re-seed when farmer changes
    const windows = ['Jul 1–15', 'Jul 16–31', 'Aug 1–15', 'Sep 1–15'];
    const prices = ['-54¢', '-52¢', '-50¢', '-48¢'];
    const offered = [12, 10, 14, 8];
    const active = Array.from({ length: farmer.activeBids }).map((_, i) => ({
      id: `${farmer.id}-b${i}`,
      window: windows[i], commodity: 'corn',
      price: prices[i], offered: offered[i],
      status: 'pending',
      history: [{ date: 'Apr 22', event: 'bid offered via call' }],
    }));
    const historical = farmer.id < 'p10' ? [
      { id: `${farmer.id}-h1`, window: 'May 1–15', commodity: 'corn', price: '-58¢', offered: 10,
        status: 'accepted', acceptedBushels: 8,
        history: [{ date: 'Mar 28', event: 'bid offered' }, { date: 'Apr 02', event: 'accepted (partial)' }] },
      { id: `${farmer.id}-h2`, window: 'May 16–31', commodity: 'beans', price: '-32¢', offered: 6,
        status: 'rejected', reason: 'Going to competitor',
        history: [{ date: 'Apr 05', event: 'bid offered' }, { date: 'Apr 08', event: 'rejected' }] },
    ] : [];
    setBids([...active, ...historical]);
  }, [farmer.id]);

  const updateBid = (next) => setBids(prev => prev.map(b => b.id === next.id ? next : b));

  const row = (k, v, mono) => (
    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', padding: '7px 0', borderBottom: `1px dashed ${PROD_MUTED}33` }}>
      <span style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{k}</span>
      <span style={{ fontFamily: mono ? '"JetBrains Mono", monospace' : '"Kalam", cursive', fontSize: '13px', fontWeight: 600 }}>{v}</span>
    </div>
  );
  return (
    <div style={{
      position: 'absolute', top: 0, right: 0, bottom: 0,
      width: '440px',
      background: PROD_BG,
      borderLeft: `2px solid ${PROD_LINE}`,
      boxShadow: '-4px 0 12px rgba(0,0,0,0.10)',
      zIndex: 20,
      display: 'flex', flexDirection: 'column',
    }}>
      <div style={{ padding: '18px 22px 14px', borderBottom: `1.5px solid ${PROD_LINE}` }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', gap: '10px' }}>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '20px', fontWeight: 700, lineHeight: 1.2 }}>
              {farmer.farmer}
            </div>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', color: PROD_MUTED, marginTop: '2px' }}>
              {farmer.biz}
            </div>
          </div>
          <button onClick={onClose} title="close" style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            fontFamily: '"Kalam", cursive', fontSize: '20px', color: PROD_MUTED,
            padding: '0 4px', lineHeight: 1,
          }}>×</button>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 22px' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
          relationship
        </div>

        {/* Facts strip — pipe-separated inline */}
        <div style={{
          display: 'flex', alignItems: 'baseline', flexWrap: 'wrap', gap: '6px 12px',
          padding: '8px 12px',
          background: PROD_PAPER,
          border: `1px solid ${PROD_LINE}22`,
          borderRadius: '2px',
          fontFamily: '"Kalam", cursive', fontSize: '12px',
          marginBottom: '8px',
        }}>
          <span><strong>{farmer.elev}</strong></span>
          <span style={{ color: PROD_MUTED }}>·</span>
          <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '11px' }}>{farmer.dist} mi</span>
          <span style={{ color: PROD_MUTED }}>·</span>
          <span style={{ color: PROD_MUTED }}>{farmer.commodities.join(', ')}</span>
          <span style={{ color: PROD_MUTED }}>·</span>
          <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: PROD_MUTED }}>
            lynx{' '}
            <a
              href={`#lynx/${farmer.id}`}
              style={{
                fontFamily: '"JetBrains Mono", monospace', fontSize: '10px',
                color: PROD_INK, fontWeight: 600,
                textDecoration: 'underline', textUnderlineOffset: '2px',
              }}
            >LX-{farmer.id.slice(1).padStart(5, '0')}</a>
          </span>
          <span style={{ color: PROD_MUTED }}>·</span>
          <a
            href={`https://example.my.salesforce.com/lightning/r/Account/${farmer.id}/view`}
            target="_blank"
            rel="noopener noreferrer"
            style={{
              fontFamily: '"Kalam", cursive', fontSize: '12px', color: PROD_ACCENT,
              textDecoration: 'underline', textUnderlineOffset: '2px',
            }}
          >Salesforce ↗</a>
          <span style={{ flex: 1 }} />
          <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: PROD_MUTED }}>
            last spot {fmtDate(farmer.lastSpot)} · last del {fmtDate(farmer.lastDelivery)}
          </span>
        </div>

        {/* Stat trio — the metrics that matter */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px' }}>
          {[
            { label: 'last contact', value: `${daysSince(farmer.lastContact)}d`, sub: fmtDate(farmer.lastContact) },
            { label: 'active bids', value: farmer.activeBids, sub: farmer.activeBids === 0 ? 'none' : 'pending response' },
            { label: 'opportunity', value: `$${(farmer.opportunity / 1000).toFixed(1)}k`, sub: 'est. $ at stake' },
          ].map(s => (
            <div key={s.label} style={{
              padding: '8px 10px',
              border: `1px solid ${PROD_LINE}22`,
              background: PROD_BG,
              borderRadius: '2px',
            }}>
              <div style={{ fontFamily: '"Kalam", cursive', fontSize: '10px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                {s.label}
              </div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '18px', fontWeight: 700, lineHeight: 1.1, marginTop: '2px' }}>
                {s.value}
              </div>
              <div style={{ fontFamily: '"Kalam", cursive', fontSize: '10px', color: PROD_MUTED, marginTop: '2px' }}>
                {s.sub}
              </div>
            </div>
          ))}
        </div>

        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', margin: '20px 0 4px' }}>
          bids
        </div>
        <div>
          {bids.length === 0 && (
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '12px', color: PROD_MUTED, padding: '10px', textAlign: 'center', background: PROD_PAPER, border: `1px dashed ${PROD_MUTED}` }}>
              no bids yet
            </div>
          )}
          {bids.map(b => <ProdBidRow key={b.id} bid={b} onUpdate={updateBid} />)}
        </div>

        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', margin: '20px 0 4px' }}>
          contact history
        </div>
        <div style={{ background: PROD_PAPER, border: `1.2px solid ${PROD_LINE}33`, borderRadius: '2px', padding: '10px 12px', fontFamily: '"Kalam", cursive', fontSize: '12px', color: PROD_MUTED, lineHeight: 1.5 }}>
          [ call log placeholder · last 5 interactions, notes, status ]
        </div>
      </div>
    </div>
  );
}

// ---------- Main view ----------

function ProducersView({ queueSide = 'right' } = {}) {
  const [search, setSearch] = React.useState('');
  const [activeFarmer, setActiveFarmer] = React.useState(null);
  const [filters, setFilters] = React.useState({
    elev: 'Sidney, OH',
    commodity: 'Corn',
  });

  const clearFilter = (key) => setFilters(prev => {
    const next = { ...prev };
    delete next[key];
    return next;
  });

  const filtered = PRODUCERS.filter(p => {
    if (filters.elev && p.elev !== filters.elev) return false;
    if (filters.commodity) {
      const want = filters.commodity.toLowerCase();
      const map = { 'corn': 'corn', 'soybeans': 'beans', 'beans': 'beans', 'wheat': 'wheat' };
      if (!p.commodities.includes(map[want] || want)) return false;
    }
    if (search) {
      const q = search.toLowerCase();
      if (!p.biz.toLowerCase().includes(q) && !p.farmer.toLowerCase().includes(q)) return false;
    }
    return true;
  });

  const headPad = '7px 12px';
  const cellPad = '8px 12px';
  const thStyle = {
    padding: headPad,
    textAlign: 'left',
    fontFamily: '"Kalam", cursive',
    fontSize: '10px',
    color: PROD_MUTED,
    textTransform: 'uppercase',
    letterSpacing: '0.07em',
    fontWeight: 600,
    borderBottom: `2px solid ${PROD_LINE}`,
    background: PROD_PAPER,
    whiteSpace: 'nowrap',
    cursor: 'pointer',
  };

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden', background: PROD_BG, display: 'flex' }}>
      {/* Use the same AppRail as scenarios */}
      <window.OptA_AppRail active="producers" />

      <div style={{ flex: 1, position: 'relative', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
        {/* Top bar */}
        <div style={{
          padding: '12px 20px',
          borderBottom: `1.5px solid ${PROD_LINE}`,
          background: PROD_PAPER,
          display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: '20px',
        }}>
          <div>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '20px', fontWeight: 700, lineHeight: 1 }}>
              Producers
            </div>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, marginTop: '2px' }}>
              {filtered.length} of {PRODUCERS.length} farmers · my call queue & lookup
            </div>
          </div>
          <div style={{ flex: 1, maxWidth: '420px', position: 'relative' }}>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by business or farmer name…"
              style={{
                width: '100%',
                padding: '8px 12px 8px 32px',
                fontFamily: '"Kalam", cursive', fontSize: '13px',
                border: `1.5px solid ${PROD_LINE}`,
                borderRadius: '2px',
                background: '#fff',
              }}
            />
            <span style={{ position: 'absolute', left: '10px', top: '50%', transform: 'translateY(-50%)', fontFamily: '"JetBrains Mono", monospace', fontSize: '14px', color: PROD_MUTED }}>⌕</span>
          </div>
          <button style={{
            fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 700,
            background: PROD_ACCENT, color: '#fff',
            border: 'none', padding: '7px 14px', borderRadius: '2px', cursor: 'pointer',
          }}>＋ new producer</button>
        </div>

        {/* Filter chip bar */}
        <div style={{
          padding: '10px 20px',
          borderBottom: `1px solid ${PROD_LINE}33`,
          background: PROD_BG,
          display: 'flex', alignItems: 'center', gap: '8px', flexWrap: 'wrap',
        }}>
          <span style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: PROD_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', marginRight: '4px' }}>
            filters:
          </span>
          {filters.elev && <ProdChip label="elevator" value={filters.elev} onClear={() => clearFilter('elev')} />}
          {filters.commodity && <ProdChip label="commodity" value={filters.commodity} onClear={() => clearFilter('commodity')} />}
          <ProdFilterDropdown label="last contact" />
          <ProdFilterDropdown label="last delivery" />
          <ProdFilterDropdown label="last spot" />
          <ProdFilterDropdown label="active bids" />
          <ProdFilterDropdown label="distance" />
          <div style={{ flex: 1 }} />
          <button style={{
            fontFamily: '"Kalam", cursive', fontSize: '11px',
            background: 'transparent', color: PROD_MUTED,
            border: 'none', cursor: 'pointer', textDecoration: 'underline',
          }}>save view</button>
        </div>

        {/* Body — table + queue */}
        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {queueSide === 'left' && (
            <ProdCallQueue producers={PRODUCERS} onPick={setActiveFarmer} openId={activeFarmer?.id} side="left" />
          )}
          <div style={{ flex: 1, overflow: 'auto' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'auto' }}>
              <thead style={{ position: 'sticky', top: 0, zIndex: 2 }}>
                <tr>
                  <th style={thStyle}>business ▾</th>
                  <th style={thStyle}>farmer</th>
                  <th style={thStyle}>elevator</th>
                  <th style={thStyle}>commodities</th>
                  <th style={thStyle}>last spot</th>
                  <th style={thStyle}>last delivery</th>
                  <th style={thStyle}>last contact</th>
                  <th style={{ ...thStyle, textAlign: 'right' }}>active bids</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((p, i) => {
                  const isOpen = activeFarmer?.id === p.id;
                  return (
                    <tr key={p.id} onClick={() => setActiveFarmer(p)} style={{
                      cursor: 'pointer',
                      background: isOpen ? PROD_ACCENT + '22' : (i % 2 ? '#f7f4ec' : PROD_BG),
                      borderBottom: `1px solid ${PROD_LINE}22`,
                    }}>
                      <td style={{ padding: cellPad, fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 600 }}>
                        {p.biz}
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"Kalam", cursive', fontSize: '13px' }}>
                        {p.farmer}
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"Kalam", cursive', fontSize: '12px', color: PROD_MUTED }}>
                        {p.elev}
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', color: PROD_MUTED }}>
                        {p.commodities.join(' · ')}
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '11px' }}>
                        {fmtDate(p.lastSpot)}
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '11px' }}>
                        {fmtDate(p.lastDelivery)}
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '11px' }}>
                        {fmtDate(p.lastContact)}
                        <span style={{ color: PROD_MUTED, marginLeft: '6px', fontSize: '10px' }}>
                          ({daysSince(p.lastContact)}d)
                        </span>
                      </td>
                      <td style={{ padding: cellPad, fontFamily: '"JetBrains Mono", monospace', fontSize: '12px', fontWeight: 700, textAlign: 'right' }}>
                        {p.activeBids > 0 ? p.activeBids : <span style={{ color: PROD_MUTED, fontWeight: 400 }}>—</span>}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {queueSide === 'right' && (
            <ProdCallQueue producers={PRODUCERS} onPick={setActiveFarmer} openId={activeFarmer?.id} side="right" />
          )}
        </div>

        <ProdFarmerDrawer farmer={activeFarmer} onClose={() => setActiveFarmer(null)} />
      </div>
    </div>
  );
}

window.ProducersView = ProducersView;

})();
