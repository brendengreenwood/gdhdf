// Scenario Editor — the "landscape builder" map view.
// Reached by clicking "revise" on any row in the scenarios table.
// Same screen used for parent scenarios AND TOS sub-scenarios — switched
// between via the folder tabs across the top.

function ScenEd_FolderTabs({ parent, tosList, activeId, onChange, onAddTos, leftAction }) {
  return (
    <div style={{
      display: 'flex',
      alignItems: 'flex-end',
      padding: '0 20px',
      gap: '2px',
      background: WF_PAPER,
      borderBottom: `1.5px solid ${WF_LINE}`,
      paddingTop: '10px',
      overflowX: 'auto',
    }}>
      {leftAction && (
        <div style={{ display: 'flex', alignItems: 'center', marginRight: '12px', paddingBottom: '8px', borderRight: `1px solid ${WF_LINE}33`, paddingRight: '12px' }}>
          {leftAction}
        </div>
      )}
      {/* Parent scenario tab */}
      <ScenEd_Tab
        active={activeId === parent.code}
        onClick={() => onChange(parent.code)}
        primary
      >
        <span style={{ fontWeight: 700 }}>{parent.label}</span>
        <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED, marginLeft: '6px' }}>
          ZC {parent.code}
        </span>
      </ScenEd_Tab>

      {/* Divider */}
      <div style={{ width: '1px', alignSelf: 'stretch', background: WF_LINE + '44', margin: '6px 6px 0' }} />

      {/* TOS sub-scenario tabs */}
      {tosList.map(t => (
        <ScenEd_Tab
          key={t.code}
          active={activeId === t.code}
          onClick={() => onChange(t.code)}
        >
          <span style={{ fontFamily: '"Kalam", cursive', fontSize: '13px' }}>
            {t.label.split(',')[0]}
          </span>
          {t.isOverride && (
            <span style={{ color: WF_ACCENT, marginLeft: '5px', fontSize: '10px' }}>⚑</span>
          )}
        </ScenEd_Tab>
      ))}

      {/* Add TOS */}
      <button onClick={onAddTos} style={{
        marginLeft: '4px', marginBottom: '0',
        padding: '8px 12px',
        border: `1.2px dashed ${WF_MUTED}`,
        borderBottom: 'none',
        borderTopLeftRadius: '4px',
        borderTopRightRadius: '4px',
        background: 'transparent',
        color: WF_MUTED,
        fontFamily: '"Kalam", cursive',
        fontSize: '12px',
        cursor: 'pointer',
        whiteSpace: 'nowrap',
      }}>＋ TOS</button>
    </div>
  );
}

function ScenEd_Tab({ children, active, onClick, primary }) {
  return (
    <button
      onClick={onClick}
      style={{
        padding: primary ? '10px 16px' : '8px 14px',
        border: `1.2px solid ${active ? WF_LINE : 'transparent'}`,
        borderBottom: active ? `1.5px solid ${WF_BG}` : `1.5px solid transparent`,
        background: active ? WF_BG : 'transparent',
        borderTopLeftRadius: '4px',
        borderTopRightRadius: '4px',
        fontFamily: '"Kalam", cursive',
        fontSize: primary ? '14px' : '13px',
        color: active ? WF_INK : WF_MUTED,
        cursor: 'pointer',
        marginBottom: '-1.5px',
        whiteSpace: 'nowrap',
      }}
    >{children}</button>
  );
}

// ---------- Mock map (sketchy SVG) ----------

// Pseudo-random but stable
function seeded(i, salt = 0) {
  const x = Math.sin(i * 9301 + 49297 + salt) * 233280;
  return x - Math.floor(x);
}

// Compute "warped voronoi" zones from a set of origin points + their bid weights.
// We just use weighted euclidean (Apollonius-ish) — enough to look right for a wireframe.
function buildZoneGrid(origins, w = 60, h = 36) {
  const grid = [];
  for (let y = 0; y < h; y++) {
    const row = [];
    for (let x = 0; x < w; x++) {
      // Find closest origin by (distance - bid_weight)
      let best = -1, bestD = Infinity;
      origins.forEach((o, i) => {
        if (o.offline) return;
        const dx = (o.x - x);
        const dy = (o.y - y);
        const dist = Math.sqrt(dx * dx + dy * dy);
        // Higher bid pulls farmers; freight pushes back per unit distance
        const effective = dist * (o.freight || 1) - (o.bid || 0) * 0.04;
        if (effective < bestD) { bestD = effective; best = i; }
      });
      row.push(best);
    }
    grid.push(row);
  }
  return grid;
}

function ScenEd_Map({ origins, levers, mapW, mapH, showFarmers = false }) {
  // Reference layout dims for origin positions (defined at this size)
  const REF_W = 760, REF_H = 460;
  const sx = mapW / REF_W;
  const sy = mapH / REF_H;
  // Compute zones at lower resolution, then render as small rects
  const gw = 60, gh = 36;
  const zones = React.useMemo(() => buildZoneGrid(origins.map(o => ({
    x: (o.mapX / REF_W) * gw,
    y: (o.mapY / REF_H) * gh,
    bid: o.bid + (o.isMerchant ? levers.posted : 0),
    freight: (o.freight || levers.freight),
    offline: o.offline,
  })), gw, gh), [origins, levers]);

  const cw = mapW / gw;
  const ch = mapH / gh;

  // Sample farmer points (deterministic)
  const farmers = React.useMemo(() => {
    if (!showFarmers) return [];
    const arr = [];
    for (let i = 0; i < 220; i++) {
      const x = seeded(i, 1) * mapW;
      const y = seeded(i, 2) * mapH;
      const gx = Math.floor((x / mapW) * gw);
      const gy = Math.floor((y / mapH) * gh);
      const ownerIdx = zones[gy] ? zones[gy][gx] : 0;
      arr.push({ x, y, ownerIdx, originator: i % 12 });
    }
    return arr;
  }, [showFarmers, zones, mapW, mapH]);

  return (
    <svg width={mapW} height={mapH} style={{ display: 'block', background: WF_PAPER }}>
      {/* Topo-ish background gridlines */}
      <defs>
        <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
          <path d="M 40 0 L 0 0 0 40" fill="none" stroke={WF_LINE + '15'} strokeWidth="1" />
        </pattern>
        <pattern id="contour" width="80" height="80" patternUnits="userSpaceOnUse">
          <circle cx="40" cy="40" r="32" fill="none" stroke={WF_LINE + '0c'} strokeWidth="1" />
          <circle cx="40" cy="40" r="20" fill="none" stroke={WF_LINE + '0c'} strokeWidth="1" />
        </pattern>
      </defs>
      <rect width={mapW} height={mapH} fill="url(#grid)" />
      <rect width={mapW} height={mapH} fill="url(#contour)" />

      {/* Zones */}
      {zones.map((row, y) => row.map((idx, x) => {
        if (idx < 0) return null;
        const o = origins[idx];
        if (!o) return null;
        return (
          <rect
            key={`${x}-${y}`}
            x={x * cw}
            y={y * ch}
            width={cw + 0.4}
            height={ch + 0.4}
            fill={o.color}
            opacity={o.isMerchant ? 0.32 : 0.16}
          />
        );
      }))}

      {/* Zone borders — draw where neighbor differs */}
      {zones.map((row, y) => row.map((idx, x) => {
        const right = row[x + 1];
        const below = zones[y + 1] && zones[y + 1][x];
        const lines = [];
        if (right !== undefined && right !== idx) {
          lines.push(<line key={`r-${x}-${y}`} x1={(x + 1) * cw} y1={y * ch} x2={(x + 1) * cw} y2={(y + 1) * ch} stroke={WF_LINE} strokeWidth="1" opacity="0.5" />);
        }
        if (below !== undefined && below !== idx) {
          lines.push(<line key={`b-${x}-${y}`} x1={x * cw} y1={(y + 1) * ch} x2={(x + 1) * cw} y2={(y + 1) * ch} stroke={WF_LINE} strokeWidth="1" opacity="0.5" />);
        }
        return lines;
      }))}

      {/* Farmer pins */}
      {farmers.map((f, i) => (
        <circle key={i} cx={f.x} cy={f.y} r="2" fill={WF_INK} opacity="0.6" />
      ))}

      {/* Origin markers */}
      {origins.map((o, i) => {
        const ox = o.mapX * sx;
        const oy = o.mapY * sy;
        return (
        <g key={i} opacity={o.offline ? 0.3 : 1}>
          {o.isMerchant ? (
            <g>
              <circle cx={ox} cy={oy} r="14" fill="none" stroke={o.color} strokeWidth="2" strokeDasharray="3 3" />
              <rect x={ox - 8} y={oy - 8} width="16" height="16" fill={o.color} stroke={WF_LINE} strokeWidth="1.5" />
              <text x={ox} y={oy + 4} textAnchor="middle" fontSize="11" fontFamily='"Kalam", cursive' fontWeight="700" fill="#fff">M</text>
            </g>
          ) : (
            <g>
              <circle cx={ox} cy={oy} r="9" fill={o.color} stroke={WF_LINE} strokeWidth="1.2" />
              <text x={ox} y={oy + 3} textAnchor="middle" fontSize="9" fontFamily='"JetBrains Mono", monospace' fontWeight="600" fill="#fff">{o.short}</text>
            </g>
          )}
          <text x={ox} y={oy + 28} textAnchor="middle" fontSize="11" fontFamily='"Kalam", cursive' fill={WF_INK} fontWeight="600">
            {o.name}
          </text>
          <text x={ox} y={oy + 41} textAnchor="middle" fontSize="10" fontFamily='"JetBrains Mono", monospace' fill={WF_MUTED}>
            {o.offline ? 'offline' : `${formatBasis(o.isMerchant ? o.bid + levers.posted : o.bid)}`}
          </text>
        </g>
        );
      })}

      {/* Compass / scale */}
      <g transform={`translate(${mapW - 70}, 20)`}>
        <circle r="14" fill="none" stroke={WF_LINE} strokeWidth="1" />
        <text y="-18" textAnchor="middle" fontSize="9" fontFamily='"Kalam", cursive' fill={WF_MUTED}>N</text>
        <line x1="0" y1="-12" x2="0" y2="12" stroke={WF_LINE} strokeWidth="1" />
        <line x1="-12" y1="0" x2="12" y2="0" stroke={WF_LINE} strokeWidth="1" />
      </g>
      <g transform={`translate(20, ${mapH - 30})`}>
        <line x1="0" y1="0" x2="60" y2="0" stroke={WF_LINE} strokeWidth="1.5" />
        <line x1="0" y1="-3" x2="0" y2="3" stroke={WF_LINE} strokeWidth="1.5" />
        <line x1="60" y1="-3" x2="60" y2="3" stroke={WF_LINE} strokeWidth="1.5" />
        <text x="30" y="14" textAnchor="middle" fontSize="9" fontFamily='"Kalam", cursive' fill={WF_MUTED}>10 mi</text>
      </g>
    </svg>
  );
}

// ---------- Lever panel ----------

function ScenEd_LeverField({ label, value, suffix, helper }) {
  return (
    <div style={{ marginBottom: '12px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '3px' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em' }}>{label}</div>
        {helper && <div style={{ fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED }}>{helper}</div>}
      </div>
      <div style={{
        display: 'flex', alignItems: 'center',
        border: `1.5px solid ${WF_LINE}`, borderRadius: '2px',
        background: '#fff',
      }}>
        <input
          defaultValue={value}
          style={{
            flex: 1,
            padding: '7px 10px',
            fontFamily: '"JetBrains Mono", monospace',
            fontSize: '14px',
            border: 'none',
            background: 'transparent',
            outline: 'none',
          }}
        />
        {suffix && <div style={{
          padding: '0 10px', fontFamily: '"JetBrains Mono", monospace',
          fontSize: '11px', color: WF_MUTED, borderLeft: `1px solid ${WF_LINE}33`,
        }}>{suffix}</div>}
      </div>
    </div>
  );
}

function ScenEd_CollapsedRail({ label, sublabel, onExpand, accent }) {
  return (
    <button
      onClick={onExpand}
      style={{
        width: '36px',
        borderRight: `1.5px solid ${WF_LINE}`,
        background: WF_PAPER,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '12px 0',
        cursor: 'pointer',
        border: 'none',
        borderTop: 0, borderBottom: 0, borderLeft: 0,
      }}
      title="expand"
    >
      <div style={{
        fontFamily: '"Kalam", cursive', fontSize: '14px', color: WF_MUTED,
      }}>›</div>
      <div style={{
        writingMode: 'vertical-rl',
        transform: 'rotate(180deg)',
        fontFamily: '"Kalam", cursive',
        fontSize: '13px',
        fontWeight: 700,
        color: accent || WF_INK,
        letterSpacing: '0.5px',
        whiteSpace: 'nowrap',
      }}>
        {label}
        {sublabel && <span style={{ color: WF_MUTED, fontWeight: 400, marginLeft: '8px' }}>· {sublabel}</span>}
      </div>
      <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '9px', color: WF_MUTED }}>☰</div>
    </button>
  );
}

function ScenEd_LeverPanel({ activeIsTos, levers, onCollapse }) {
  return (
    <div style={{
      width: '320px',
      borderRight: `1.5px solid ${WF_LINE}`,
      background: WF_BG,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px dashed ${WF_MUTED}`, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '14px', fontWeight: 700, marginBottom: '2px' }}>
            {activeIsTos ? 'TOS levers' : 'Scenario levers'}
          </div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED }}>
            drives the price calculator
          </div>
        </div>
        <button onClick={onCollapse} title="collapse" style={{
          background: 'transparent', border: 'none', cursor: 'pointer',
          fontFamily: '"Kalam", cursive', fontSize: '14px', color: WF_MUTED,
          padding: '0 4px', lineHeight: 1,
        }}>‹</button>
      </div>

      <div style={{ padding: '14px 18px', overflowY: 'auto', flex: 1 }}>
        {activeIsTos && (
          <div style={{ marginBottom: '14px', padding: '10px 12px', background: WF_PAPER, border: `1px solid ${WF_LINE}33`, borderRadius: '2px' }}>
            <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase', marginBottom: '6px' }}>delivery window</div>
            <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
              <input defaultValue="Jul 1, 2026" style={smallInput} />
              <span style={{ color: WF_MUTED }}>→</span>
              <input defaultValue="Jul 15, 2026" style={smallInput} />
            </div>
          </div>
        )}

        <ScenEd_LeverField label="posted bid" value="-55" suffix="¢ basis" helper={activeIsTos ? '⚑ override' : null} />
        <ScenEd_LeverField label="max bid" value="-45" suffix="¢ basis" helper={activeIsTos ? '↳ inherit' : null} />
        <ScenEd_LeverField label="price leeway" value="3" suffix="¢" />
        <ScenEd_LeverField label="bid increment" value="2" suffix="¢" />
        <ScenEd_LeverField label="freight" value="0.45" suffix="$/mi" />
      </div>

    </div>
  );
}

function ScenEd_CompetitorPanel({ competitors, onAddCompetitor, onToggleCompetitor, onCollapse }) {
  const onCount = competitors.filter(c => !c.offline).length;
  return (
    <div style={{
      width: '300px',
      borderRight: `1.5px solid ${WF_LINE}`,
      background: WF_BG,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px dashed ${WF_MUTED}`, display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '14px', fontWeight: 700, marginBottom: '2px' }}>
            Competitors
          </div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED }}>
            {onCount} of {competitors.length} active · auto-loaded
          </div>
        </div>
        <div style={{ display: 'flex', gap: '6px', alignItems: 'center' }}>
          <button onClick={onAddCompetitor} style={{
            fontFamily: '"Kalam", cursive', fontSize: '11px',
            background: 'transparent', border: `1px solid ${WF_ACCENT}`,
            color: WF_ACCENT, cursor: 'pointer',
            padding: '3px 8px', borderRadius: '2px',
          }}>＋ add</button>
          <button onClick={onCollapse} title="collapse" style={{
            background: 'transparent', border: 'none', cursor: 'pointer',
            fontFamily: '"Kalam", cursive', fontSize: '14px', color: WF_MUTED,
            padding: '0 4px', lineHeight: 1,
          }}>‹</button>
        </div>
      </div>

      <div style={{ padding: '8px 0', overflowY: 'auto', flex: 1 }}>
        {competitors.map(c => (
          <div key={c.id} style={{
            display: 'flex', alignItems: 'center', gap: '10px',
            padding: '10px 18px',
            borderBottom: `1px dashed ${WF_MUTED}33`,
            opacity: c.offline ? 0.55 : 1,
            background: c.offline ? WF_PAPER : 'transparent',
          }}>
            <div style={{
              width: '18px', height: '18px', borderRadius: '50%',
              background: c.color, border: `1.5px solid ${WF_LINE}`,
              flexShrink: 0,
              display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontFamily: '"JetBrains Mono", monospace', fontSize: '8px',
              color: '#fff', fontWeight: 700,
            }}>{c.short}</div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 600, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>
                {c.name}
              </div>
              <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '9px', color: WF_MUTED }}>
                {c.manual ? '✎ manual entry' : 'auto · DTN feed'}
              </div>
            </div>
            <input defaultValue={c.bid} style={{
              width: '54px', padding: '4px 6px',
              fontFamily: '"JetBrains Mono", monospace', fontSize: '12px',
              border: `1px solid ${WF_LINE}55`, borderRadius: '2px',
              background: '#fff', textAlign: 'right',
            }} />
            <button onClick={() => onToggleCompetitor(c.id)} title={c.offline ? 'enable' : 'disable'} style={{
              fontFamily: '"JetBrains Mono", monospace', fontSize: '10px',
              background: c.offline ? 'transparent' : WF_LINE,
              border: `1px solid ${WF_LINE}`,
              borderRadius: '2px',
              padding: '3px 7px',
              cursor: 'pointer',
              color: c.offline ? WF_MUTED : '#fff',
              minWidth: '32px',
            }}>{c.offline ? 'off' : 'on'}</button>
          </div>
        ))}
      </div>

      <div style={{ padding: '10px 18px', borderTop: `1px solid ${WF_LINE}33`, background: WF_PAPER, fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED, lineHeight: 1.4 }}>
        Edit a posted bid or toggle a competitor offline to see the landscape recompute.
      </div>
    </div>
  );
}

const smallInput = {
  flex: 1,
  padding: '4px 8px',
  fontFamily: '"JetBrains Mono", monospace',
  fontSize: '12px',
  border: `1px solid ${WF_LINE}66`,
  borderRadius: '2px',
  background: '#fff',
};

// ---------- Sub-nav (Build / Explore landscape) ----------

function ScenEd_SubNav({ subView, onChange, context }) {
  const items = [
    { id: 'build',   label: 'Build',             hint: 'levers · competitors' },
    { id: 'explore', label: 'Explore landscape', hint: 'map · zones · farmers' },
  ];
  return (
    <div style={{
      display: 'flex',
      alignItems: 'stretch',
      borderBottom: `1.5px solid ${WF_LINE}`,
      background: WF_BG,
      paddingLeft: '20px',
    }}>
      {items.map(it => {
        const active = subView === it.id;
        return (
          <button
            key={it.id}
            onClick={() => onChange(it.id)}
            style={{
              fontFamily: '"Kalam", cursive',
              background: 'transparent',
              border: 'none',
              borderBottom: active ? `2px solid ${WF_ACCENT}` : '2px solid transparent',
              padding: '10px 18px 8px',
              cursor: 'pointer',
              textAlign: 'left',
              color: active ? WF_INK : WF_MUTED,
            }}
          >
            <div style={{ fontSize: '14px', fontWeight: active ? 700 : 500 }}>{it.label}</div>
            <div style={{ fontSize: '10px', color: WF_MUTED, marginTop: '1px' }}>{it.hint}</div>
          </button>
        );
      })}
      <div style={{ flex: 1 }} />
      <div style={{
        display: 'flex', alignItems: 'center', gap: '10px',
        paddingRight: '20px',
        fontFamily: '"Kalam", cursive', fontSize: '12px', color: WF_MUTED,
      }}>
        <span>{context}</span>
        <WfBtn small>save draft</WfBtn>
        <WfBtn small primary>publish →</WfBtn>
      </div>
    </div>
  );
}

// ---------- Main scenario editor screen ----------

function ScenarioEditor() {
  const parent = { code: 'N26', label: 'Jul 2026' };
  const tosList = [
    { code: 'N26-A', label: 'Jul 1-15, 2026', isOverride: true },
    { code: 'N26-B', label: 'Jul 16-31, 2026', isOverride: false },
  ];
  const [activeTab, setActiveTab] = React.useState('N26-A');
  const activeIsTos = activeTab !== 'N26';

  // Origins on the map: merchant + competitors
  const [competitors, setCompetitors] = React.useState([
    { id: 'gp',  name: 'Grain Pro Lima',     short: 'GP', color: '#2563eb', mapX: 540, mapY: 130, bid: -52, freight: 0.42, offline: false, manual: false },
    { id: 'fs',  name: 'Farmside Coop',      short: 'FS', color: '#047857', mapX: 200, mapY: 220, bid: -58, freight: 0.48, offline: false, manual: false },
    { id: 'rd',  name: 'River Delta',        short: 'RD', color: '#7c3aed', mapX: 460, mapY: 360, bid: -54, freight: 0.45, offline: false, manual: false },
    { id: 'wb',  name: 'Westbrook Elev.',    short: 'WB', color: '#b91c1c', mapX: 100, mapY: 380, bid: -60, freight: 0.50, offline: true,  manual: false },
    { id: 'mn',  name: 'Mason Mill',         short: 'MN', color: '#0891b2', mapX: 640, mapY: 280, bid: -57, freight: 0.46, offline: false, manual: true  },
  ]);
  const merchant = { id: 'me', name: 'Prairie Grove', short: 'M', color: WF_ACCENT, mapX: 320, mapY: 250, bid: -55, freight: 0.45, isMerchant: true };
  const origins = [merchant, ...competitors];
  const levers = { posted: 0, freight: 0.45 };

  const onToggle = (id) => setCompetitors(prev => prev.map(c => c.id === id ? { ...c, offline: !c.offline } : c));
  const onAddTos = () => {};
  const onAddCompetitor = () => {};

  const [subView, setSubView] = React.useState('build'); // 'build' | 'explore'
  const [leversCollapsed, setLeversCollapsed] = React.useState(true);
  const [competitorsCollapsed, setCompetitorsCollapsed] = React.useState(true);
  const [farmersCollapsed, setFarmersCollapsed] = React.useState(true);
  const [exclusions, setExclusions] = React.useState({
    lastSpot: false,
    lastContacted: false,
    inactive90: false,
    noContract: false,
  });

  // Mock originators (10–15 in real life)
  const originators = [
    { id: 'jt', name: 'Jamie Thornton', color: '#b45309', count: 24, total: 285_000, avg: -54 },
    { id: 'sw', name: 'Sara Wexler',    color: '#7c2d12', count: 19, total: 220_400, avg: -53 },
    { id: 'rh', name: 'Ray Holcomb',    color: '#365314', count: 27, total: 312_800, avg: -56 },
    { id: 'mp', name: 'Marcus Pell',    color: '#0f766e', count: 14, total: 168_200, avg: -55 },
    { id: 'lb', name: 'Lisa Burdick',   color: '#6d28d9', count: 21, total: 251_700, avg: -54 },
    { id: 'dn', name: 'Dan Nakamura',   color: '#be123c', count: 18, total: 198_600, avg: -57 },
    { id: 'ek', name: 'Emily Kovach',   color: '#1d4ed8', count: 16, total: 184_300, avg: -55 },
    { id: 'tr', name: 'Tom Reilly',     color: '#a16207', count: 23, total: 268_900, avg: -54 },
    { id: 'cv', name: 'Carla Vance',    color: '#0e7490', count: 12, total: 142_500, avg: -56 },
    { id: 'po', name: 'Pat Olson',      color: '#831843', count: 20, total: 234_100, avg: -55 },
    { id: 'gw', name: 'Greg Wahl',      color: '#4d7c0f', count: 17, total: 195_400, avg: -53 },
    { id: 'jh', name: 'Jess Harlow',    color: '#9333ea', count: 9,  total: 102_300, avg: -56 },
  ];
  const farmerCount = originators.reduce((a, o) => a + o.count, 0);

  return (
    <div style={{ position: 'relative', width: '100%', height: '100%', overflow: 'hidden', background: WF_BG, display: 'flex' }}>
      <OptA_AppRail active="scenarios" />
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>

        <ScenEd_FolderTabs
          parent={parent}
          tosList={tosList}
          activeId={activeTab}
          onChange={setActiveTab}
          onAddTos={onAddTos}
          leftAction={
            <a href="#" onClick={(e) => e.preventDefault()} style={{
              display: 'inline-flex', alignItems: 'center', gap: '4px',
              fontFamily: '"Kalam", cursive', fontSize: '12px',
              color: WF_MUTED, textDecoration: 'none',
              whiteSpace: 'nowrap',
            }}>← Scenarios</a>
          }
        />

        <ScenEd_SubNav
          subView={subView}
          onChange={setSubView}
          context="Corn · Prairie Grove · Apr 21, 2026"
        />

        {/* Inheritance breadcrumb */}
        {activeIsTos && (
          <div style={{
            padding: '6px 20px',
            background: WF_BG,
            borderBottom: `1px dashed ${WF_MUTED}55`,
            fontFamily: '"Kalam", cursive', fontSize: '11px',
            color: WF_MUTED,
            display: 'flex', alignItems: 'center', gap: '8px',
          }}>
            <span>↳ TOS sub-scenario of</span>
            <a href="#" onClick={(e) => { e.preventDefault(); setActiveTab(parent.code); }} style={{ color: WF_INK, fontWeight: 600 }}>
              {parent.label}
            </a>
            <span>· editing the landscape for this delivery window only</span>
          </div>
        )}

        <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
          {subView === 'build' ? (
            <>
              {leversCollapsed ? (
                <ScenEd_CollapsedRail
                  label={activeIsTos ? 'TOS levers' : 'Scenario levers'}
                  sublabel="5 fields"
                  onExpand={() => setLeversCollapsed(false)}
                />
              ) : (
                <ScenEd_LeverPanel
                  activeIsTos={activeIsTos}
                  levers={levers}
                  onCollapse={() => setLeversCollapsed(true)}
                />
              )}
              {competitorsCollapsed ? (
                <ScenEd_CollapsedRail
                  label="Competitors"
                  sublabel={`${competitors.filter(c => !c.offline).length} active`}
                  onExpand={() => setCompetitorsCollapsed(false)}
                />
              ) : (
                <ScenEd_CompetitorPanel
                  competitors={competitors}
                  onAddCompetitor={onAddCompetitor}
                  onToggleCompetitor={onToggle}
                  onCollapse={() => setCompetitorsCollapsed(true)}
                />
              )}

              <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: WF_PAPER }}>
                <ScenEd_FullMap origins={origins} levers={levers} competitors={competitors} />
              </div>
            </>
          ) : (
            <>
              {farmersCollapsed ? (
                <ScenEd_CollapsedRail
                  label="Farmers"
                  sublabel={`${farmerCount} in zone · ${originators.length} originators`}
                  onExpand={() => setFarmersCollapsed(false)}
                />
              ) : (
                <ScenEd_FarmersPanel
                  originators={originators}
                  exclusions={exclusions}
                  setExclusions={setExclusions}
                  farmerCount={farmerCount}
                  onCollapse={() => setFarmersCollapsed(true)}
                />
              )}

              <div style={{ flex: 1, position: 'relative', overflow: 'hidden', background: WF_PAPER }}>
                <ScenEd_FullMap origins={origins} levers={levers} competitors={competitors} />
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// ---------- Farmers panel (Explore view) ----------

function ScenEd_FarmersPanel({ originators, exclusions, setExclusions, farmerCount, onCollapse }) {
  const [openSet, setOpenSet] = React.useState(new Set());
  const toggle = (id) => setOpenSet(prev => {
    const n = new Set(prev);
    n.has(id) ? n.delete(id) : n.add(id);
    return n;
  });
  const totalActive = originators.reduce((a, o) => a + o.count, 0);
  // Pretend each exclusion takes some farmers away (visual mock)
  const excludedCount =
    (exclusions.lastSpot ? 18 : 0) +
    (exclusions.lastContacted ? 27 : 0) +
    (exclusions.inactive90 ? 12 : 0) +
    (exclusions.noContract ? 22 : 0);
  const includedCount = Math.max(0, totalActive - excludedCount);

  return (
    <div style={{
      width: '340px',
      borderRight: `1.5px solid ${WF_LINE}`,
      background: WF_BG,
      display: 'flex',
      flexDirection: 'column',
      overflow: 'hidden',
    }}>
      <div style={{ padding: '14px 18px', borderBottom: `1px dashed ${WF_MUTED}`, display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '14px', fontWeight: 700, marginBottom: '2px' }}>
            Farmers in zone
          </div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED }}>
            {includedCount} included · {excludedCount} excluded · {originators.length} originators
          </div>
        </div>
        <button onClick={onCollapse} title="collapse" style={{
          background: 'transparent', border: 'none', cursor: 'pointer',
          fontFamily: '"Kalam", cursive', fontSize: '14px', color: WF_MUTED,
          padding: '0 4px', lineHeight: 1,
        }}>‹</button>
      </div>

      {/* Exclusions filter */}
      <div style={{ padding: '12px 18px', borderBottom: `1px dashed ${WF_MUTED}`, background: WF_PAPER }}>
        <label style={{
          display: 'flex', alignItems: 'center', gap: '8px',
          fontFamily: '"Kalam", cursive', fontSize: '12px',
          fontWeight: 700,
          cursor: 'pointer',
          padding: '4px 0 8px',
          borderBottom: `1px dashed ${WF_MUTED}33`,
          marginBottom: '8px',
        }}>
          <input type="checkbox" defaultChecked style={{ accentColor: WF_ACCENT }} />
          <span style={{ flex: 1 }}>Select all farmers in my zone</span>
          <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED, fontWeight: 400 }}>{farmerCount}</span>
        </label>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
          exclusions
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px' }}>
          {[
            { key: 'lastSpot', label: 'Last spot accounts', hint: '18 farmers' },
            { key: 'lastContacted', label: 'Last contacted < 7d', hint: '27 farmers' },
            { key: 'inactive90', label: 'Inactive > 90 days', hint: '12 farmers' },
            { key: 'noContract', label: 'No active contract', hint: '22 farmers' },
          ].map(ex => (
            <label key={ex.key} style={{
              display: 'flex', alignItems: 'center', gap: '8px',
              fontFamily: '"Kalam", cursive', fontSize: '12px',
              cursor: 'pointer',
              padding: '4px 0',
            }}>
              <input
                type="checkbox"
                checked={exclusions[ex.key]}
                onChange={() => setExclusions(prev => ({ ...prev, [ex.key]: !prev[ex.key] }))}
                style={{ accentColor: WF_ACCENT }}
              />
              <span style={{ flex: 1 }}>{ex.label}</span>
              <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>−{ex.hint}</span>
            </label>
          ))}
        </div>
      </div>

      {/* Originator accordions */}
      <div style={{ overflowY: 'auto', flex: 1 }}>
        {originators.map(o => {
          const isOpen = openSet.has(o.id);
          return (
            <div key={o.id} style={{ borderBottom: `1px dashed ${WF_MUTED}33` }}>
              <button onClick={() => toggle(o.id)} style={{
                width: '100%',
                display: 'flex', alignItems: 'center', gap: '10px',
                padding: '10px 18px',
                background: 'transparent', border: 'none',
                cursor: 'pointer', textAlign: 'left',
              }}>
                <span style={{
                  width: '14px', display: 'inline-block', textAlign: 'center',
                  fontFamily: '"JetBrains Mono", monospace', fontSize: '11px', color: WF_MUTED,
                }}>{isOpen ? '▾' : '▸'}</span>
                <span style={{
                  width: '12px', height: '12px', borderRadius: '50%',
                  background: o.color, border: `1px solid ${WF_LINE}`,
                  flexShrink: 0,
                }} />
                <span style={{ flex: 1, fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 600 }}>
                  {o.name}
                </span>
                <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>
                  {o.count} · {(o.total / 1000).toFixed(0)}k bu
                </span>
              </button>
              {isOpen && (
                <div style={{ padding: '4px 18px 12px 42px', background: WF_PAPER }}>
                  {Array.from({ length: Math.min(4, o.count) }).map((_, i) => (
                    <div key={i} style={{
                      display: 'flex', justifyContent: 'space-between', alignItems: 'baseline',
                      padding: '4px 0',
                      borderBottom: `1px dashed ${WF_MUTED}22`,
                      fontFamily: '"Kalam", cursive', fontSize: '11px',
                    }}>
                      <span>Farmer #{i + 1}</span>
                      <span style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>
                        {formatBasis(o.avg + (i % 3) - 1)} · {(8 + i * 3)}k bu
                      </span>
                    </div>
                  ))}
                  {o.count > 4 && (
                    <div style={{ padding: '4px 0', fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED }}>
                      + {o.count - 4} more …
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div style={{ padding: '10px 18px', borderTop: `1px solid ${WF_LINE}33`, background: WF_PAPER, fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED, lineHeight: 1.4 }}>
        Pins on the map are colored by originator. Excluded farmers fade out.
      </div>
    </div>
  );
}

// ---------- Full-bleed map for Explore view ----------

function MapIconBtn({ children, label, active }) {
  return (
    <button
      title={label}
      style={{
        width: '36px', height: '36px',
        background: active ? WF_ACCENT + '22' : 'transparent',
        border: 'none',
        cursor: 'pointer',
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontFamily: '"Kalam", cursive',
        fontSize: '18px',
        color: active ? WF_ACCENT : WF_INK,
        fontWeight: active ? 700 : 400,
      }}
    >{children}</button>
  );
}

function ScenEd_FullMap({ origins, levers, competitors }) {
  const ref = React.useRef(null);
  const [size, setSize] = React.useState({ w: 800, h: 500 });

  React.useEffect(() => {
    if (!ref.current) return;
    const ro = new ResizeObserver(entries => {
      for (const e of entries) {
        const cr = e.contentRect;
        setSize({ w: Math.max(200, Math.floor(cr.width)), h: Math.max(200, Math.floor(cr.height)) });
      }
    });
    ro.observe(ref.current);
    return () => ro.disconnect();
  }, []);

  return (
    <div ref={ref} style={{ position: 'absolute', inset: 0 }}>
      <ScenEd_Map origins={origins} levers={levers} mapW={size.w} mapH={size.h} showFarmers={false} />

      {/* Zoom controls — top right */}
      <div style={{
        position: 'absolute', top: '14px', right: '14px',
        display: 'flex', flexDirection: 'column',
        background: 'rgba(255,253,247,0.94)',
        border: `1px solid ${WF_LINE}55`,
        borderRadius: '2px',
        backdropFilter: 'blur(2px)',
        overflow: 'hidden',
      }}>
        <MapIconBtn label="zoom in">＋</MapIconBtn>
        <div style={{ height: '1px', background: WF_LINE + '33' }} />
        <MapIconBtn label="zoom out">−</MapIconBtn>
        <div style={{ height: '1px', background: WF_LINE + '33' }} />
        <MapIconBtn label="fit to zone">⊡</MapIconBtn>
      </div>

      {/* Tool controls — below zoom */}
      <div style={{
        position: 'absolute', top: '152px', right: '14px',
        display: 'flex', flexDirection: 'column',
        background: 'rgba(255,253,247,0.94)',
        border: `1px solid ${WF_LINE}55`,
        borderRadius: '2px',
        backdropFilter: 'blur(2px)',
        overflow: 'hidden',
      }}>
        <MapIconBtn label="pan tool" active>✥</MapIconBtn>
        <div style={{ height: '1px', background: WF_LINE + '33' }} />
        <MapIconBtn label="lasso select">◌</MapIconBtn>
      </div>

      {/* Layer controls — bottom right */}
      <div style={{
        position: 'absolute', bottom: '14px', right: '14px',
        display: 'flex', flexDirection: 'column', gap: '6px',
        background: 'rgba(255,253,247,0.94)',
        border: `1px solid ${WF_LINE}55`,
        borderRadius: '2px',
        padding: '10px 12px',
        backdropFilter: 'blur(2px)',
      }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '2px' }}>
          layers
        </div>
        <div style={{ display: 'flex', gap: '6px' }}>
          <WfBtn small>farmers</WfBtn>
          <WfBtn small>heatmap</WfBtn>
        </div>
        <div style={{ display: 'flex', gap: '6px', marginTop: '4px' }}>
          <WfBtn small>↻ recalc</WfBtn>
        </div>
      </div>

      {/* Floating title top-left */}
      <div style={{
        position: 'absolute', top: '14px', left: '14px',
        background: 'rgba(255,253,247,0.94)',
        border: `1px solid ${WF_LINE}55`,
        borderRadius: '2px',
        padding: '10px 14px',
        backdropFilter: 'blur(2px)',
        maxWidth: '320px',
      }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '14px', fontWeight: 700 }}>
          Pricing landscape
        </div>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, marginTop: '2px' }}>
          zones recompute live · {competitors.length} competitors · ~220 farmers in draw area
        </div>
      </div>

      {/* Floating legend bottom-left */}
      <div style={{
        position: 'absolute', bottom: '14px', left: '14px',
        background: 'rgba(255,253,247,0.94)',
        border: `1px solid ${WF_LINE}55`,
        borderRadius: '2px',
        padding: '10px 14px',
        backdropFilter: 'blur(2px)',
        display: 'flex', flexDirection: 'column', gap: '4px',
        fontFamily: '"Kalam", cursive', fontSize: '11px',
        maxWidth: '260px',
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
          <div style={{ width: '12px', height: '12px', background: WF_ACCENT, opacity: 0.32 }} />
          <span style={{ fontWeight: 600 }}>Prairie Grove (you)</span>
        </div>
        {competitors.map(c => (
          <div key={c.id} style={{ display: 'flex', alignItems: 'center', gap: '6px', opacity: c.offline ? 0.4 : 1 }}>
            <div style={{ width: '12px', height: '12px', background: c.color, opacity: 0.5 }} />
            <span>{c.name}{c.offline ? ' · offline' : ''}</span>
          </div>
        ))}
        <div style={{ marginTop: '4px', paddingTop: '4px', borderTop: `1px dashed ${WF_LINE}55`, color: WF_MUTED, fontSize: '10px' }}>
          zone color = winning origin · darker = stronger pull
        </div>
      </div>
    </div>
  );
}

window.ScenarioEditor = ScenarioEditor;