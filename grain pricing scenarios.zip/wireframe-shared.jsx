// Shared wireframe primitives — sketchy b&w with one accent
// Used by all 4 options.

const WF_ACCENT = '#d97706'; // amber accent
const WF_RED = '#b91c1c';
const WF_INK = '#1a1a1a';
const WF_MUTED = '#8a8a8a';
const WF_LINE = '#2a2a2a';
const WF_BG = '#fafaf7';
const WF_PAPER = '#f4f1ea';

// CME corn futures contracts — 2026 only, 3 scenarios
const CORN_CONTRACTS = [
  { code: 'N26', month: 'Jul', year: '2026', label: 'Jul 2026' },
  { code: 'U26', month: 'Sep', year: '2026', label: 'Sep 2026' },
  { code: 'Z26', month: 'Dec', year: '2026', label: 'Dec 2026' },
];

// Half-month delivery windows mapped to each futures contract
// Corn futures deliver in Mar, May, Jul, Sep, Dec. Map calendar months:
// Feb 1-15, Feb 16-28 -> H (Mar)
// Mar 1-15, Mar 16-31, Apr 1-15, Apr 16-30 -> K (May)
// May 1-15, May 16-31, Jun 1-15, Jun 16-30 -> N (Jul)
// Jul 1-15, Jul 16-31, Aug 1-15, Aug 16-31 -> U (Sep)
// Sep 1-15, Sep 16-30, Oct 1-15, Oct 16-31, Nov 1-15, Nov 16-30 -> Z (Dec)
// (simplified to give each futures contract 2-4 delivery windows)

const DELIVERY_WINDOWS = {
  // N26 — no windows (not expandable)
  N26: [],
  // U26 — has windows
  U26: [
    { code: 'U26-A', label: 'Jul 1-15, 2026' },
    { code: 'U26-B', label: 'Jul 16-31, 2026' },
    { code: 'U26-C', label: 'Aug 1-15, 2026' },
    { code: 'U26-D', label: 'Aug 16-31, 2026' },
  ],
  // Z26 — no windows (not expandable)
  Z26: [],
};

// Sample pricing data — posted bid, max bid, leeway, increment
// All values are basis (cents under/over futures)
const PRICING_DATA = {
  K26:   { posted: -25, max: -18, leeway: 2, increment: 1, updated: 'Apr 21, 9:14 AM', by: 'T. Renner' },
  N26:   { posted: -30, max: -22, leeway: 2, increment: 1, updated: 'Apr 21, 9:14 AM', by: 'T. Renner' },
  U26:   { posted: -42, max: -35, leeway: 3, increment: 1, updated: 'Apr 20, 4:02 PM', by: 'T. Renner' },
  Z26:   { posted: -55, max: -45, leeway: 3, increment: 2, updated: 'Apr 21, 8:30 AM', by: 'J. Alvaro' },
  H27:   { posted: -48, max: -40, leeway: 3, increment: 2, updated: 'Apr 18, 2:15 PM', by: 'J. Alvaro' },
  K27:   { posted: -38, max: -30, leeway: 3, increment: 2, updated: 'Apr 18, 2:15 PM', by: 'J. Alvaro' },
  N27:   { posted: -35, max: -28, leeway: 4, increment: 2, updated: 'Apr 15, 11:20 AM', by: 'T. Renner' },
  U27:   { posted: -50, max: -40, leeway: 4, increment: 2, updated: 'Apr 10, 3:45 PM', by: 'T. Renner' },
  Z27:   { posted: -62, max: -50, leeway: 5, increment: 2, updated: 'Apr 10, 3:45 PM', by: 'T. Renner' },
};

// Per-delivery-window overrides (if any) — most inherit from futures parent
// Just a few overrides to show the concept
const WINDOW_OVERRIDES = {
  'N26-A': { posted: -28 }, // closer window, better bid
  'N26-B': { posted: -29 },
  'Z26-A': { posted: -50 }, // earliest Z window
  'Z26-B': { posted: -52 },
  'H27-A': { posted: -45 },
};

// TOS = Total Offered Size, in bushels, per delivery window
const WINDOW_TOS = {
  'K26-A': 25000,  'K26-B': 25000,
  'N26-A': 50000,  'N26-B': 50000,  'N26-C': 40000,  'N26-D': 40000,
  'U26-A': 30000,  'U26-B': 30000,  'U26-C': 25000,  'U26-D': 25000,
  'Z26-A': 75000,  'Z26-B': 75000,  'Z26-C': 100000, 'Z26-D': 100000, 'Z26-E': 80000,  'Z26-F': 80000,
  'H27-A': 60000,  'H27-B': 60000,  'H27-C': 50000,  'H27-D': 50000,  'H27-E': 40000,  'H27-F': 40000,
  'K27-A': 30000,  'K27-B': 30000,  'K27-C': 25000,  'K27-D': 25000,
  'N27-A': 35000,  'N27-B': 35000,  'N27-C': 30000,  'N27-D': 30000,
  'U27-A': 25000,  'U27-B': 25000,  'U27-C': 20000,  'U27-D': 20000,
  'Z27-A': 50000,  'Z27-B': 50000,  'Z27-C': 60000,  'Z27-D': 60000,
};

function getWindowTOS(windowCode) {
  return WINDOW_TOS[windowCode] || 0;
}

function getParentTOS(parentCode) {
  const windows = DELIVERY_WINDOWS[parentCode] || [];
  return windows.reduce((sum, w) => sum + getWindowTOS(w.code), 0);
}

function formatTOS(bu) {
  if (!bu) return '—';
  if (bu >= 1000) return `${(bu / 1000).toFixed(0)}k bu`;
  return `${bu} bu`;
}

function getWindowPricing(parentCode, windowCode) {
  const base = PRICING_DATA[parentCode];
  const override = WINDOW_OVERRIDES[windowCode] || {};
  return { ...base, ...override, isOverride: Object.keys(override).length > 0 };
}

function formatBasis(cents) {
  if (cents === undefined || cents === null) return '—';
  const sign = cents > 0 ? '+' : '';
  return `${sign}${cents}¢`;
}

// Sketchy border — uses a slightly rotated inset box-shadow feel via border
const wfBox = {
  border: `1.5px solid ${WF_LINE}`,
  background: WF_BG,
  borderRadius: '2px',
};

const wfBoxPaper = {
  ...wfBox,
  background: WF_PAPER,
};

// Hand-drawn underline used for labels
function Underline({ width = 60, offset = 0, color = WF_LINE }) {
  return (
    <svg width={width} height="6" style={{ display: 'block', marginTop: '2px' }}>
      <path
        d={`M 2 3 Q ${width * 0.25} ${1 + offset} ${width * 0.5} 3 T ${width - 2} 3`}
        stroke={color}
        strokeWidth="1.5"
        fill="none"
        strokeLinecap="round"
      />
    </svg>
  );
}

// Small sketchy checkbox/pill for status
function WfPill({ children, color = WF_LINE, filled = false }) {
  return (
    <span style={{
      display: 'inline-block',
      padding: '2px 8px',
      border: `1.2px solid ${color}`,
      borderRadius: '10px',
      fontSize: '10px',
      fontFamily: '"Kalam", cursive',
      color: filled ? WF_BG : color,
      background: filled ? color : 'transparent',
      letterSpacing: '0.02em',
    }}>{children}</span>
  );
}

// Label + value stacked
function WfField({ label, value, width, mono = true, emphasis = false }) {
  return (
    <div style={{ minWidth: width, flex: width ? '0 0 auto' : 1 }}>
      <div style={{
        fontFamily: '"Kalam", cursive',
        fontSize: '10px',
        color: WF_MUTED,
        letterSpacing: '0.04em',
        textTransform: 'uppercase',
      }}>{label}</div>
      <div style={{
        fontFamily: mono ? '"JetBrains Mono", monospace' : '"Kalam", cursive',
        fontSize: emphasis ? '18px' : '14px',
        fontWeight: emphasis ? 700 : 500,
        color: emphasis ? WF_RED : WF_INK,
        marginTop: '2px',
      }}>{value}</div>
    </div>
  );
}

// Sketchy button
function WfBtn({ children, primary = false, small = false, onClick, style }) {
  return (
    <button
      onClick={onClick}
      style={{
        fontFamily: '"Kalam", cursive',
        fontSize: small ? '11px' : '13px',
        padding: small ? '3px 10px' : '6px 14px',
        border: `1.5px solid ${primary ? WF_ACCENT : WF_LINE}`,
        background: primary ? WF_ACCENT : 'transparent',
        color: primary ? '#fff' : WF_INK,
        borderRadius: '3px',
        cursor: 'pointer',
        letterSpacing: '0.02em',
        whiteSpace: 'nowrap',
        ...style,
      }}
    >{children}</button>
  );
}

// Placeholder zone (striped)
function WfPlaceholder({ h = 80, label }) {
  return (
    <div style={{
      height: h,
      border: `1.2px dashed ${WF_MUTED}`,
      background: `repeating-linear-gradient(135deg, transparent 0 6px, rgba(0,0,0,0.04) 6px 7px)`,
      borderRadius: '2px',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      fontFamily: '"JetBrains Mono", monospace',
      fontSize: '10px',
      color: WF_MUTED,
      letterSpacing: '0.05em',
      textTransform: 'uppercase',
    }}>{label}</div>
  );
}

// Top bar used across all options
function WfTopBar({ title, subtitle, right }) {
  return (
    <div style={{
      padding: '14px 22px',
      borderBottom: `1.5px solid ${WF_LINE}`,
      background: WF_PAPER,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      gap: '16px',
      whiteSpace: 'nowrap',
    }}>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: '16px', whiteSpace: 'nowrap' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '22px', fontWeight: 700, whiteSpace: 'nowrap' }}>
          {title || 'Corn · Pricing Scenarios'}
        </div>
      </div>
      {right && <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>{right}</div>}
    </div>
  );
}

Object.assign(window, {
  WF_ACCENT, WF_RED, WF_INK, WF_MUTED, WF_LINE, WF_BG, WF_PAPER,
  CORN_CONTRACTS, DELIVERY_WINDOWS, PRICING_DATA, WINDOW_OVERRIDES,
  WINDOW_TOS, getWindowTOS, getParentTOS, formatTOS,
  getWindowPricing, formatBasis,
  wfBox, wfBoxPaper,
  Underline, WfPill, WfField, WfBtn, WfPlaceholder, WfTopBar,
});
