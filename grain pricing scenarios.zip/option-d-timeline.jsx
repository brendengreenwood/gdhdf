// Option D — Timeline / calendar strip
// A horizontal timeline of half-month delivery windows across 2 years.
// Above each window, a visual bar shows which futures contract it maps to,
// color-banded so you see "all Sept–Nov 2026 rolls into Z26" at a glance.
// Futures contracts are top-level cards stacked along the top; click a card
// to focus that contract's windows and edit in a dedicated side drawer.
// Revise = dedicated edit page (bottom half of the screen).

function OptD_FuturesCard({ contract, active, onClick }) {
  const p = PRICING_DATA[contract.code];
  const windowCount = (DELIVERY_WINDOWS[contract.code] || []).length;
  return (
    <div onClick={onClick} style={{
      ...wfBox,
      padding: '10px 12px',
      cursor: 'pointer',
      background: active ? WF_ACCENT : WF_BG,
      color: active ? '#fff' : WF_INK,
      borderColor: active ? WF_ACCENT : WF_LINE,
      minWidth: '130px',
      flex: '0 0 auto',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '15px', fontWeight: 700 }}>
          {contract.code}
        </div>
        <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', opacity: 0.7 }}>
          {windowCount}w
        </div>
      </div>
      <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', opacity: 0.85, marginTop: '2px' }}>
        {contract.label}
      </div>
      <div style={{
        fontFamily: '"JetBrains Mono", monospace',
        fontSize: '14px',
        fontWeight: 700,
        marginTop: '6px',
        color: active ? '#fff' : WF_RED,
      }}>
        {formatBasis(p.posted)}
      </div>
    </div>
  );
}

// Build a flat ordered list of all windows with their parent, in calendar order
function buildTimeline() {
  const rows = [];
  CORN_CONTRACTS.forEach(c => {
    (DELIVERY_WINDOWS[c.code] || []).forEach(w => {
      rows.push({ parentCode: c.code, parentLabel: c.label, window: w });
    });
  });
  return rows;
}

function OptD_TimelineWindow({ row, idx, totalInGroup, focused, dimmed, onClick }) {
  const wp = getWindowPricing(row.parentCode, row.window.code);
  return (
    <div
      onClick={onClick}
      style={{
        ...wfBox,
        padding: '6px 8px',
        minWidth: '92px',
        flex: '0 0 auto',
        background: focused ? '#fff' : (dimmed ? WF_BG : WF_PAPER),
        opacity: dimmed ? 0.35 : 1,
        borderColor: focused ? WF_ACCENT : WF_LINE,
        borderWidth: focused ? '2px' : '1.2px',
        cursor: 'pointer',
      }}
    >
      <div style={{ fontFamily: '"Kalam", cursive', fontSize: '10px', color: WF_MUTED, textTransform: 'uppercase', letterSpacing: '0.04em' }}>
        {row.window.label.split(',')[0]}
      </div>
      <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '14px', fontWeight: 700, color: wp.isOverride ? WF_ACCENT : WF_INK }}>
        {formatBasis(wp.posted)}
      </div>
      <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '9px', color: WF_MUTED }}>
        {wp.isOverride ? '⚑ override' : '↳ parent'}
      </div>
    </div>
  );
}

function OptD_RevisePane({ contract, onClose }) {
  const p = PRICING_DATA[contract.code];
  const windows = DELIVERY_WINDOWS[contract.code] || [];
  return (
    <div style={{
      background: WF_PAPER,
      borderTop: `2px solid ${WF_LINE}`,
      padding: '16px 22px',
      height: '46%',
      overflowY: 'auto',
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '18px', fontWeight: 700 }}>
            Revise · {contract.label} <span style={{ color: WF_MUTED, fontSize: '13px', marginLeft: '8px' }}>+ {windows.length} windows</span>
          </div>
          <div style={{ fontFamily: '"JetBrains Mono", monospace', fontSize: '10px', color: WF_MUTED }}>
            ZC {contract.code} · last saved {p.updated} by {p.by}
          </div>
        </div>
        <div style={{ display: 'flex', gap: '8px' }}>
          <WfBtn small onClick={onClose}>cancel</WfBtn>
          <WfBtn small primary>save & publish</WfBtn>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '300px 1fr', gap: '20px', marginTop: '14px' }}>
        {/* Parent editor */}
        <div style={{ ...wfBox, padding: '12px 14px', background: WF_BG }}>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 700, marginBottom: '8px' }}>
            Parent config
          </div>
          {[
            ['posted bid', p.posted + '¢'],
            ['max bid', p.max + '¢'],
            ['leeway', p.leeway + '¢'],
            ['increment', p.increment + '¢'],
          ].map(([label, val]) => (
            <div key={label} style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '6px' }}>
              <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED }}>{label}</div>
              <input defaultValue={val} style={{
                width: '90px', fontFamily: '"JetBrains Mono", monospace', fontSize: '12px',
                padding: '4px 8px', border: `1.2px solid ${WF_LINE}`, borderRadius: '2px',
                background: '#fff', textAlign: 'right',
              }} />
            </div>
          ))}
          <WfBtn small style={{ marginTop: '6px', width: '100%' }}>propagate to all windows</WfBtn>
        </div>

        {/* Per-window editor grid */}
        <div>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', fontWeight: 700, marginBottom: '8px' }}>
            Per-window overrides
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '10px' }}>
            {windows.map(w => {
              const wp = getWindowPricing(contract.code, w.code);
              return (
                <div key={w.code} style={{
                  ...wfBox, padding: '8px 10px', background: wp.isOverride ? '#fff5e6' : WF_BG,
                  borderColor: wp.isOverride ? WF_ACCENT : WF_LINE,
                }}>
                  <div style={{ fontFamily: '"Kalam", cursive', fontSize: '12px', fontWeight: 600 }}>
                    {w.label}
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '4px', marginTop: '6px' }}>
                    <input placeholder="posted" defaultValue={wp.posted} style={miniInput} />
                    <input placeholder="max" defaultValue={wp.max} style={miniInput} />
                    <input placeholder="leeway" defaultValue={wp.leeway} style={miniInput} />
                    <input placeholder="incr" defaultValue={wp.increment} style={miniInput} />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

const miniInput = {
  fontFamily: '"JetBrains Mono", monospace', fontSize: '11px',
  padding: '3px 6px', border: `1px solid ${WF_LINE}66`,
  borderRadius: '2px', background: '#fff', width: '100%', boxSizing: 'border-box',
};

function OptionD() {
  const [activeContract, setActiveContract] = React.useState('Z26');
  const [revising, setRevising] = React.useState(null);
  const timeline = buildTimeline();

  return (
    <div style={{ width: '100%', height: '100%', background: WF_BG, display: 'flex', flexDirection: 'column' }}>
      <WfTopBar subtitle="timeline · futures ⇄ delivery windows" />

      {/* Futures cards strip */}
      <div style={{ padding: '14px 20px 10px', borderBottom: `1px dashed ${WF_MUTED}` }}>
        <div style={{ fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED, textTransform: 'uppercase', letterSpacing: '0.05em', marginBottom: '8px' }}>
          futures contracts · click to focus · 2 year strip
        </div>
        <div style={{ display: 'flex', gap: '8px', overflowX: 'auto', paddingBottom: '4px' }}>
          {CORN_CONTRACTS.map(c => (
            <OptD_FuturesCard
              key={c.code}
              contract={c}
              active={activeContract === c.code}
              onClick={() => setActiveContract(c.code)}
            />
          ))}
        </div>
      </div>

      {/* Timeline */}
      <div style={{ flex: revising ? 'initial' : 1, padding: '16px 20px', overflow: 'auto', background: `repeating-linear-gradient(90deg, transparent 0 60px, ${WF_LINE}08 60px 61px)` }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '10px' }}>
          <div style={{ fontFamily: '"Kalam", cursive', fontSize: '13px', color: WF_MUTED }}>
            delivery windows · Apr 2026 → Oct 2027 · focused on <strong style={{ color: WF_ACCENT }}>{activeContract}</strong>
          </div>
          <WfBtn small primary onClick={() => setRevising(CORN_CONTRACTS.find(c => c.code === activeContract))}>
            revise {activeContract} →
          </WfBtn>
        </div>

        {/* Contract bands above timeline */}
        <div style={{ display: 'flex', gap: '4px', marginBottom: '6px' }}>
          {CORN_CONTRACTS.map(c => {
            const n = (DELIVERY_WINDOWS[c.code] || []).length;
            const isActive = c.code === activeContract;
            return (
              <div key={c.code} style={{
                width: `${n * 96}px`,
                flex: '0 0 auto',
                background: isActive ? WF_ACCENT : WF_LINE + '22',
                color: isActive ? '#fff' : WF_INK,
                padding: '4px 10px',
                fontFamily: '"Kalam", cursive', fontSize: '11px', fontWeight: 600,
                borderRadius: '2px',
                textAlign: 'center',
                letterSpacing: '0.04em',
              }}>
                ↓ {c.code} · {c.label}
              </div>
            );
          })}
        </div>

        {/* Windows row */}
        <div style={{ display: 'flex', gap: '4px' }}>
          {timeline.map((row, i) => (
            <OptD_TimelineWindow
              key={row.window.code}
              row={row}
              idx={i}
              focused={row.parentCode === activeContract}
              dimmed={row.parentCode !== activeContract}
              onClick={() => setActiveContract(row.parentCode)}
            />
          ))}
        </div>

        {/* Legend */}
        <div style={{ marginTop: '18px', display: 'flex', gap: '16px', fontFamily: '"Kalam", cursive', fontSize: '11px', color: WF_MUTED }}>
          <span>◼ focused contract</span>
          <span style={{ color: WF_ACCENT }}>⚑ override window</span>
          <span>↳ inherits parent</span>
        </div>
      </div>

      {revising && <OptD_RevisePane contract={revising} onClose={() => setRevising(null)} />}
    </div>
  );
}

window.OptionD = OptionD;
