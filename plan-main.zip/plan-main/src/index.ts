import {
	createTool,
	defineMastraCodePlugin,
	writeToolProgress,
	z,
} from "mastracode/plugin"
import type { ToolExecutionContext } from "mastracode/plugin"
import { bootLocalAgentController } from "mastracode"

import { basename } from "node:path"

type NestedAgentMode = NonNullable<
	NonNullable<Parameters<typeof bootLocalAgentController>[0]>["modes"]
>[number]

type ToolContext =
	| Pick<ToolExecutionContext, "writer" | "agent" | "abortSignal">
	| undefined

type MessageContentPart = { type: string; text?: string }
type MessageContent =
	| MessageContentPart[]
	| { parts?: MessageContentPart[] }
	| undefined

type AssistantMessage = {
	role?: string
	content?: MessageContent
}

type EventRecord = {
	type: string
	message?: AssistantMessage
	toolName?: string
	toolCallId?: string
	args?: unknown
	result?: unknown
	isError?: boolean
	error?: unknown
}

function collectAssistantText(events: EventRecord[]): string {
	const parts: string[] = []
	for (const event of events) {
		if (event.type === "message_end" && event.message?.role === "assistant") {
			parts.push(extractAssistantText(event.message))
		}
	}
	return parts.join("")
}

function extractAssistantText(message: AssistantMessage | undefined): string {
	if (message?.role !== "assistant") return ""

	const content = message.content
	const parts = Array.isArray(content) ? content : content?.parts ?? []

	return parts
		.filter(
			(part): part is MessageContentPart & { type: "text"; text: string } =>
				part.type === "text" && typeof part.text === "string",
		)
		.map((part) => part.text)
		.join("")
}

function createProgressRenderer(toolCtx: ToolContext) {
	const startedAt = Date.now()

	return {
		handleEvent(event: EventRecord) {
			if (event.type === "message_update" || event.type === "message_end") {
				const text = extractAssistantText(event.message).trim()
				if (text) {
					void writeToolProgress(toolCtx, {
						event: "text",
						text,
					})
				}
				return
			}

			if (event.type === "tool_start") {
				void writeToolProgress(toolCtx, {
					event: "tool_start",
					toolName: event.toolName ?? "tool",
					args: event.args,
				})
				return
			}

			if (event.type === "tool_end") {
				void writeToolProgress(toolCtx, {
					event: "tool_end",
					toolName: event.toolName ?? "tool",
					result: event.error ?? event.result,
					isError: event.isError || !!event.error,
				})
			}
		},
		async finish(result: string, isError = false) {
			await writeToolProgress(toolCtx, {
				event: "finish",
				durationMs: Date.now() - startedAt,
				result,
				isError,
			})
		},
	}
}

function buildReviewerMode(): NestedAgentMode {
	return {
		id: "reviewer",
		name: "Adversarial Reviewer",
		description:
			"Read-only cold-eyes reviewer. Inspects a branch diff or plan file and reports findings.",
		instructions: `You are an adversarial reviewer with persistent memory per piece of work: the first message about a piece of work arrives cold — everything you know arrives in that message, plus whatever you read from the repository yourself — and later messages about the same work continue the same conversation (re-reviews after fixes, the implementation review after the plan review). You have READ-ONLY access — you can read files, search, and inspect code, but you cannot edit files or run commands. You inspect; you never fix.

On re-reviews, memory is for skipping re-orientation, not for rubber-stamping your own past conclusions. Never take "fixed" on faith — re-read the code each earlier finding pointed at and verify the fix actually landed. Your earlier findings are not ground truth either: if a fix (or a fresh read) shows a finding was wrong, say so and drop it. And re-check whether the fixes introduced new problems — deltas get the same skepticism the original got.

Your job is to find what's wrong, not to validate. Assume the author is competent and still made mistakes — everyone does. Hunt for: bugs and logic mistakes, missing edge cases, unnecessary complexity, weak or missing tests, dead code and accidental churn, brittleness, changes that fight patterns established by the file history, and scope creep against the stated goal and do-not list. When reviewing a plan document, additionally check it against any rubric the message points you to: phases self-contained for a cold executor, verification gates proven not claimed, judge criteria checkable by a cold reader.

Build your own context before judging: read the files involved, and use git history context if the message tells you how to get it. Do not take the message's framing as ground truth — verify claims against the code.

Report findings in exactly three sections: **Must fix** (defects — bugs, broken behavior, violations of stated constraints), **Risks & questions** (things that might be wrong or need the author's answer), **Suggested improvements** (better ways that aren't defects). Every finding cites file:line or plan section. If a section is empty, say so in one line. Be direct, dense, and skeptical — no praise padding, no hedging, no summaries of what the change does.`,
		availableTools: [
			"view",
			"find_files",
			"search_content",
			"file_stat",
			"lsp_inspect",
		],
	}
}

async function runReview(opts: {
	cwd: string
	modelId: string | undefined
	threadId: string | undefined
	message: string
	sandboxAllowedPaths: string[]
	toolCtx: ToolContext
	renderer: ReturnType<typeof createProgressRenderer>
}): Promise<string> {
	const { cwd, modelId, threadId, message, sandboxAllowedPaths, toolCtx, renderer } =
		opts
	const mc = await bootLocalAgentController({
		cwd,
		modes: [buildReviewerMode()],
		// Never load plugins in the nested agent: this plugin would
		// load itself and expose its tools recursively.
		disablePlugins: true,
		disableMcp: true,
		disableHooks: true,
		initialState: {
			...(modelId ? { currentModelId: modelId } : {}),
			// Inherit the parent agent's extra filesystem grants (request_access)
			// so reviewers can read code that lives outside the project root.
			...(sandboxAllowedPaths.length > 0 ? { sandboxAllowedPaths } : {}),
		},
	})
	if (modelId) {
		mc.session.model.set({ modelId })
	}
	const abortNestedRun = () => mc.session.abort()
	if (toolCtx?.abortSignal?.aborted) {
		abortNestedRun()
	} else {
		toolCtx?.abortSignal?.addEventListener("abort", abortNestedRun, {
			once: true,
		})
	}

	// Reviewers keep memory per (parent thread, plan, model): the first
	// round arrives cold, later rounds (re-reviews, implementation review)
	// continue the same conversation instead of re-orienting from zero.
	const sessionResourceId =
		mc.session.identity?.getResourceId?.() ?? "plan-reviewer"
	const memoryStore = mc.storage?.stores?.memory
	if (threadId && memoryStore?.saveThread && memoryStore?.getThreadById) {
		try {
			const existing = await memoryStore.getThreadById({ threadId })
			if (!existing || existing.resourceId !== sessionResourceId) {
				if (existing && memoryStore.deleteThread) {
					await memoryStore.deleteThread({ threadId })
				}
				await memoryStore.saveThread({
					thread: {
						id: threadId,
						resourceId: sessionResourceId,
						title: "Adversarial Reviewer",
						metadata: { sandboxAllowedPaths },
						createdAt: new Date(),
						updatedAt: new Date(),
					},
				})
			} else if (memoryStore.updateThread) {
				// Refresh the grant set: the per-thread state restore that runs on
				// thread switch reads it from thread metadata, and the parent's
				// grants may have changed since the previous review round.
				await memoryStore.updateThread({
					id: threadId,
					title: existing.title ?? "Adversarial Reviewer",
					metadata: { ...existing.metadata, sandboxAllowedPaths },
				})
			}
		} catch {}
	}

	const events: EventRecord[] = []
	const unsubscribe = mc.session.subscribe((event) => {
		const record = event as unknown as EventRecord
		events.push(record)
		renderer.handleEvent(record)
	})

	try {
		if (threadId) {
			try {
				await mc.session.thread.switch({ threadId })
			} catch (e) {
				return `Thread switch failed for ${threadId}: ${String(e)}`
			}
		} else {
			await mc.session.thread.create()
		}
		// Thread switch can restore a saved mode/model; force ours.
		mc.session.mode.set({ modeId: "reviewer" })
		if (modelId) {
			mc.session.model.set({ modelId })
		}
		// Re-apply inherited filesystem grants: thread switch/create restores
		// per-thread state from thread metadata (clearing it when absent), which
		// can wipe the initialState seed. Persist to metadata first so a late
		// async restore reads the same grants back instead of clearing them.
		if (sandboxAllowedPaths.length > 0) {
			try {
				await mc.session.thread.setSetting({
					key: "sandboxAllowedPaths",
					value: sandboxAllowedPaths,
				})
				await mc.session.state.set({ sandboxAllowedPaths })
			} catch {}
		}
		await mc.session.sendMessage({ content: message })
	} finally {
		unsubscribe()
		mc.session.abort()
		await Promise.allSettled([
			mc.mcpManager?.disconnect(),
			mc.controller.getMastra()?.stopWorkers(),
			mc.controller.destroy(),
		])
		toolCtx?.abortSignal?.removeEventListener("abort", abortNestedRun)
	}

	return collectAssistantText(events)
}

export default defineMastraCodePlugin({
	id: "plan",
	name: "Plan",
	description:
		"Adds the /plan goal command: solo goal-ready planning with parallel, multi-model adversarial reviews via the adversarial_review tool.",
	config: {
		reviewModel1: {
			type: "model",
			label: "Review model 1",
			description:
				"First adversarial_review model. Each configured review model runs an independent parallel cold review; overlapping findings are a high-confidence signal. Falls back to the session model when no review models are set.",
		},
		reviewModel2: {
			type: "model",
			label: "Review model 2",
			description:
				"Second adversarial_review model (optional). Prefer a different provider/family than review model 1 - different models have different blind spots.",
		},
		reviewModel3: {
			type: "model",
			label: "Review model 3",
			description:
				"Third adversarial_review model (optional).",
		},
	},
	instructions:
		"Use the adversarial_review tool when a plan or command choreography calls for an adversarial review (plan draft reviews, a plan's final ship-checks phase, or a mid-run review the plan prescribes). It runs independent, read-only reviews — one per configured review model, in parallel — and returns each reviewer's findings separately. Reviewers keep memory per plan_path: the first call arrives cold, so that prompt must be self-contained (goal, do-not list, branch and how to get the diff, or the plan file path and rubric location); later calls with the same plan_path continue each reviewer's conversation, so state what changed since the last round instead of repeating the briefing. When multiple reviews return, triage them yourself: findings reported by more than one reviewer are high-confidence; conflicting findings get flagged rather than silently resolved.",
	tools: (pluginContext) => {
		const configuredReviewModels = [
			pluginContext.config.reviewModel1,
			pluginContext.config.reviewModel2,
			pluginContext.config.reviewModel3,
		].filter((m): m is string => typeof m === "string" && m.length > 0)
		return {
			adversarial_review: {
				tool: createTool({
					id: "adversarial_review",
					description:
						"Run independent, read-only adversarial reviews — one per configured review model, in parallel. Use when a plan or command choreography calls for adversarial review (plan drafts, final ship checks, or a plan-prescribed mid-run review). Each reviewer keeps its own memory per plan: the first call about a plan arrives cold, and later calls with the same plan_path (re-reviews after fixes, the implementation review) continue that reviewer's conversation, so reviewers skip re-orientation but re-verify claimed fixes against the code. The FIRST prompt for a plan must be fully self-contained — the goal, the do-not list, the branch name and how to get the diff (or the plan file path and where the rubric lives), and anything else needed to judge the work; later prompts state what changed since the last round. Reviewers inspect only; they never edit. Returns each reviewer's findings (Must fix / Risks & questions / Suggested improvements) as separate labeled sections — triage overlaps and conflicts yourself.",
					inputSchema: z.object({
						prompt: z.string(),
						plan_path: z
							.string()
							.describe(
								"Path to the plan file governing the work under review (e.g. .mastracode/plans/my-feature.md). Keys the reviewers' persistent memory — use the same path across every review round for the same plan.",
							),
					}),
					execute: async (
						input: { prompt: string; plan_path: string },
						toolCtx?: ToolExecutionContext,
					) => {
						const renderer = createProgressRenderer(toolCtx)
						const controller = toolCtx?.requestContext?.get("controller") as
							| {
									session?: { modelId?: string }
									getState?: () => { sandboxAllowedPaths?: string[] }
							  }
							| undefined
						// Inherit the parent agent's extra filesystem grants
						// (request_access approvals) so reviewers can read code
						// outside the project root, e.g. a sibling repo.
						const sandboxAllowedPaths =
							controller?.getState?.()?.sandboxAllowedPaths ?? []
						const modelIds: (string | undefined)[] =
							configuredReviewModels.length > 0
								? configuredReviewModels
								: [controller?.session?.modelId]
						const parentThreadId = toolCtx?.agent?.threadId ?? undefined
						const planSlug = basename(input.plan_path)
							.replace(/\.[^.]+$/, "")
							.replace(/[^a-zA-Z0-9._-]+/g, "-")
						void writeToolProgress(toolCtx, {
							event: "text",
							text: `Booting ${modelIds.length} reviewer${modelIds.length === 1 ? "" : "s"}: ${modelIds.map((m) => m ?? "session model").join(", ")}`,
						})
						const settled = await Promise.allSettled(
							modelIds.map((modelId) => {
								const modelSlug = (modelId ?? "session-model").replace(
									/[^a-zA-Z0-9._-]+/g,
									"-",
								)
								return runReview({
									cwd: pluginContext.cwd,
									modelId,
									threadId: parentThreadId
										? `${parentThreadId}--${planSlug}--${modelSlug}`
										: undefined,
									message: input.prompt,
									sandboxAllowedPaths,
									toolCtx,
									renderer,
								})
							}),
						)
						const reviews = settled.map((outcome, i) => {
							const model = modelIds[i] ?? "session model"
							return outcome.status === "fulfilled"
								? { model, review: outcome.value }
								: { model, error: String(outcome.reason) }
						})
						const failures = reviews.filter((r) => "error" in r).length
						await renderer.finish(
							`${reviews.length - failures}/${reviews.length} reviews completed`,
							failures === reviews.length,
						)
						return { reviews }
					},
				}),
				render: {
					type: "subagent" as const,
					label: "review",
					agentType: "adversary",
					maxActivityLines: 28,
					collapsedLines: 28,
					colors: {
						border: "#f97316",
						label: "#fb923c",
						agentType: "#fdba74",
					},
					icons: {
						running: "…",
						success: "✓",
						error: "✗",
					},
				},
			},
		}
	},
})
