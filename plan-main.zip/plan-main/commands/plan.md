---
name: plan
description: Produce a goal-ready implementation plan - research, outline design, user approval, draft, adversarial review, submit
goal: true
---

# Plan

Produce a goal-ready implementation plan. The user's instruction for what to plan is:

"""
$ARGUMENTS
"""

If the quoted instruction above is empty, the objective is whatever the current conversation has been working toward — infer it, state it in one sentence, and proceed. If the conversation doesn't point at anything concrete, ask the user.

You do this solo — research, outline design, and drafting are all yours. Because no second set of eyes designs the plan, be deliberately skeptical of your own first idea: design the outline from the evidence, not from the approach you had in mind before researching, and state why the chosen shape won over at least one alternative. Cold eyes arrive later, at draft review — the adversarial reviewers, not you, judge whether the plan holds up.

The phases below are named, not numbered, to avoid colliding with the numbered phases of the plan being designed.

## Phase: Research

Do the archaeology proactively — no pausing, no outline-building yet (the two exceptions that *do* pause mid-research: grilling and premise challenges, both below). For each area the objective touches:

- **History**: `git log --oneline -20 -- <file>`, `git blame` on the regions involved, read the PRs/issues behind the shaping commits (`gh pr view`, `gh issue view`). Use `NO_COLOR=1` or `gh --jq` — ANSI codes break `jq`.
- **Architecture**: read the surrounding code, trace interfaces and data flow, read AGENTS.md/README in affected packages and at the repo root (they encode conventions and environment setup).
- **Tests**: read the tests for affected areas; note how similar things are tested elsewhere.
- **Prior art**: `gh pr list --search "<keywords>" --state all --limit 20` and the same for issues — has someone tried this before? Was it reverted?
- **Gate shapes**: execute one representative focused test command (e.g. a focused vitest run) and record the exact working shape and its output — broken gate commands discovered at draft time are expensive. If it fails because the environment isn't set up (fresh worktree, unbuilt workspace packages, unresolvable imports), run the repo's **documented** setup commands verbatim (AGENTS.md / CONTRIBUTING / README), then re-probe. Never improvise setup: no guessed build commands, no partial variants of documented ones. If no documented setup exists or the documented commands fail, stop — record exactly what you ran and its output, and surface it to the user; a repo whose documented setup fails is a finding about the repo, not something to engineer around. Environment state is never a design input.

**Grill the user when the ask underdetermines the work.** Research answers everything the codebase can answer — never ask the user what a file read would tell you. But complex features often leave genuine product decisions open that no amount of archaeology resolves: behavior on edge cases, API shape preferences, scope boundaries, tradeoffs between valid designs. When you find these, interview the user before designing: stop (waiting state) and ask **one question at a time, each with your recommended answer and why**, so the user can just say "yes" or redirect. Dependent decisions stay one-per-stop — later questions change shape based on earlier answers; only batch questions that are truly independent. Small, unambiguous asks skip this entirely — don't manufacture questions to look thorough.

**Challenge the ask when the evidence contradicts it.** Research validates the request itself, not just how to execute it. If the archaeology shows the ask rests on a wrong premise — the "bug" is intended behavior with history behind it, the feature already exists, the request is an XY problem (names a mechanism when the real problem has a better solution), the approach fights the architecture, or doing it would break something the user hasn't considered — say so **before designing anything**. But a wrong ask almost always points at a real problem — the user didn't ask for nothing. Before challenging, work out **why they're asking**: from the conversation, linked issues, and the evidence itself, try to infer the underlying problem the stated ask was trying to solve. How confident you are decides how you open:

- **Confident inference** → present the diagnosis as a hypothesis to confirm: (1) here's what I think you're actually trying to solve — am I right?, (2) here's why the ask as stated doesn't get you there (file:line, PRs, history), (3) here's what would actually address the underlying problem, as my recommendation. Options follow that shape — confirm the underlying problem and adjust the objective / correct my read of what you're after / proceed as asked anyway.
- **Can't infer it** → don't guess at them; ask. Use the grilling pattern (one question per stop, with your best guess as the recommended answer when you have one): what's the symptom or situation that prompted this? what would be different if it worked? Ask until you understand what they're after, *then* present the evidence against the stated ask together with the path that serves the real goal.

Either way the posture is diagnosis, not verdict — the questions and the challenge are the same conversation, aimed at leaving with an objective worth planning. Being asked doesn't make it right, and dutifully planning a request you believe is wrong wastes the whole pipeline — when the premise is bad, the diagnosis *is* the deliverable. If the user proceeds as asked after seeing the evidence, that's their call to make: record the challenge and their decision in the plan's Context findings and plan it well.

**Don't finish the archaeology on a premise you doubt — triage it first.** The moment evidence casts doubt on the premise, stop working the general checklist and chase the cheapest *decisive* evidence for the premise question specifically — usually one `git blame` → PR read ("intentional, here's the discussion") or one existence check ("this already exists at X"). Suggestive doubt → keep digging, but at the premise; decisive contradiction → stop and challenge now with what you have. The remaining research is contingent on which objective survives the conversation — completing it first is the waste. Note in one line that the remaining archaeology is deferred pending direction (no enumerated per-branch research plans — that's bookkeeping the user doesn't need), and resume against the resolved objective afterward (most gathered evidence usually carries over).

Organize the findings as evidence — file:line refs, commit SHAs, PR numbers, working gate command shapes with output — and a single paragraph stating what you believe the ask is: problem and constraints.

**Judge criteria — Research**: complete when the stop report shows (1) research evidence with file:line/PR references covering history, architecture, tests, and prior art for each affected area, (2) at least one gate command executed with real output, and (3) open product decisions either answered by the user during this phase or explicitly carried forward as decisions for the outline. If the evidence contradicted the ask, the phase is only complete once the challenge was presented and the user resolved the direction — proceeding past a known-bad premise without surfacing it fails this phase. A stop report that pauses research early to challenge the premise is a **valid intermediate stop**, not a failed phase: it needs the decisive contradicting evidence and a one-line note that remaining research is deferred pending direction. A missing or thin deferral note is never grounds for a continue verdict — the blocking event is the user's answer, so the verdict is waiting; full coverage is enforced by these criteria after direction is resolved and research resumes. Spot-check one or two cited claims with readonly tools; do not re-do the research.

## Phase: Outline approval

Design the plan outline from the findings: named phases (never just numbers) with scope, verification approach, and rationale per phase grounded in the evidence; a do-not list covering the target work only; and any decision that belongs to the human called out explicitly. State why this shape won over the alternative(s) you considered.

If the work decomposes into multiple independently reviewable PRs (or one PR would be unreviewably large), propose a **plan set** per the rubric's Plan sets section: the outline shows the segments, their PR boundaries, and the stacking order, and states the cadence — each segment ends with a pushed branch and a draft PR, no human gate between segments. That cadence is part of what the user is approving.

If the research shows the work is genuinely small, propose the **fast path** per the rubric's Fast path section as an explicit option letter — two phases, all evidence requirements intact.

If the work changes user-observable behavior, the outline carries a **proof plan** — activate the `prove-it` skill and follow its Proof plan section. Present it as its own labeled block in the outline message: "here's how I'll prove this to you and to myself" — the proposed demo method and surface, the realism ladder (the realer alternatives and why they're not needed, if you're proposing anything less than the most real), how red will be shown for fixes, and which phase(s) build and run the demo. If you're claiming the exemption (pure refactor, type-level, docs), say so with the reason. The proof plan gets **its own lettered options** alongside the outline's: approve as proposed, each viable realer alternative as its own letter, and always a standing "not real enough — propose something closer to what a real user does" option.

Present it to the user. Present any flagged decision as an explicit lettered option with your recommendation. End with tailored options, e.g.:

```text
A) Approve the outline — draft the full plan
B) <the flagged decision, option 1>
C) <the flagged decision, option 2>
D) Change the outline — tell me what's wrong

Proof plan:
E) Prove it as proposed — <the recommended method>
F) <the realer alternative — e.g. packed tarball in a temp project instead of a script>
G) Not real enough — propose something closer to what a real user does
```

Then go to the **waiting** state. Do not draft anything before the user responds.

**The gate passes only on explicit, unconditional approval.** Any other response — a question, a new idea, an objection, a partial approval ("A, but what about…") — means the gate has not been passed. When that happens, take the detour: engage the discussion as a conversation, going back to **waiting** after each reply. Do not answer and immediately re-present the lettered options every turn, and never resolve an open design question yourself and proceed — approval alongside an open question is conditional and does not count until the user confirms after the discussion. Only once the discussion has reached consensus do you re-present the outline (updated if any decision changed) with fresh options.

**Judge criteria — Outline approval**: complete when an outline grounded in the research evidence was presented with rationale and a stated alternative, flagged decisions appeared as explicit options, the proof plan appeared as its own block with its own options (proposed method, realer alternatives, the standing "not real enough" option) or an exemption was claimed with its reason, and the user explicitly and unconditionally approved — a user reply containing an open question or new idea does not satisfy approval, even if it also contains an approval letter. Nor does it authorize work in the other direction: never treat the executor's answer or recommendation to an unanswered user question as a user directive — while the user's question is the latest message, the verdict is *waiting*, not *continue*. Discussion turns end in *waiting*; the goal is not stalled, it needs user input.

## Phase: Draft and review

1. Activate the `plan-rubric` skill and follow it exactly. Write the plan to `.mastracode/plans/<descriptive-name>.md`, expanding the approved outline: named phases with Implementation / Tests / Verification gate / Commit / Stop point / Judge criteria, header sections, progress-file rules, final ship-checks phase with adversarial review and human approval gate. For an approved plan set, follow the rubric's Plan sets layout instead: main plan plus one segment file per PR. The iteration protocol's escalation path is **the user** — design divergences stop and report for the user to decide.
2. Prove every gate command shape in the draft by execution (reuse the Research-phase evidence where the shape is identical; execute any new shapes now).
3. Have the draft adversarially reviewed — independent eyes are the point. Prefer the `adversarial_review` tool (independent parallel reviews on the configured models; pass the plan file as `plan_path` — reviewers keep memory per plan, so re-review rounds after fixes reuse the same `plan_path` and state only what changed); fall back to a **non-forked** subagent if unavailable (forked subagents inherit your framing and investment). Either way the first reviewer prompt must be self-contained: the plan file path, where the `plan-rubric` skill lives, and direction to check — does each phase's design actually follow from the stated evidence, are the phases self-contained for a cold executor, are judge criteria checkable by a cold judge, do gate commands have execution proof, does the plan implement the user-approved proof plan (the approved method, not a quietly less-real substitute; demo built and run inside the implementation phases, artifacts verified at ship checks) or an honestly claimed exemption, is anything missing or over-scoped. Reviewers inspect only — they never edit. With multiple reviews, triage: findings from more than one reviewer are high-confidence; conflicts get flagged, not silently resolved. Apply required findings to the file or explicitly state in the stop report why a finding is wrong. If neither tool is available, note that in the stop report — the judge's rubric verification below covers it.
4. **Come to a full stop — do not call `submit_plan` yet.** The goal judge verifies the draft against the rubric before the user sees it. Your stop report must contain: the plan file path, the path to the `plan-rubric` skill's SKILL.md (so the judge can read the rubric itself), the gate-command execution evidence, and the review findings with how each was resolved. Then wait for the judge's verdict: fix what it sends back, stop again, and repeat until it verifies.

**Judge criteria — Draft and review**: read the rubric at the SKILL.md path in the stop report, then read the plan file (for a plan set, the main plan and every segment file it indexes — verify them against the rubric's Plan sets section), and verify the plan follows the rubric's rules — named self-contained phases with Implementation / Tests / Verification gate / Commit / Stop point / Judge criteria, Context findings header, do-not list scoped to the target work only, iteration protocol with the user as the stated escalation path, progress-file rules, final ship-checks phase with adversarial review and human approval gate, live proof implementing the user-approved proof plan — the approved demo method (not a less-real substitute), demo-building placed inside the implementation phases and the artifacts named in the ship-checks judge criteria, or the explicitly approved exemption — judge criteria written for a cold reader, commit suggestions with no trailers. Also verify every gate shape has execution evidence (output, not claims) and the adversarial review's findings appear unfiltered in the stop report with each applied or explicitly rebutted. If anything falls short, send the executor back with the specific violations — do not pass a draft on the executor's word.

## Phase: Submit

Only after the judge has verified the draft, submit the plan file with `submit_plan`. Briefly tell the user what the plan contains (phases, key decisions, anything the review forced to change) and go to the **waiting** state. The user approving the submitted plan — and optionally starting it as a goal — is the end of this command. Only explicit user action completes it. The same gate rule applies here: questions or new ideas at this stage are a discussion detour, not approval — engage them and return to **waiting** until the user explicitly decides.

**Judge criteria — Submit**: complete when `submit_plan` was called with the reviewed plan file and the run is in *waiting* for the user's decision. Even with every prior criterion verified, do not mark the goal complete — the user has the final say.

## Rules

- Do not modify product code, commit, or push during this command — the only file you write is the plan file (and nothing under version control).
- Scale research to the stakes; a small fix needs hours less archaeology than a core-interface change.
- Stop reports carry evidence, not narration: what was run, what it output, what was decided.
