# Plan

A [Mastra Code](https://mastra.ai) plugin for producing goal-ready implementation plans, reviewed by cold parallel adversarial reviewers.

Sibling of [plan-architect](../plan-architect) (this one is just called `plan`) — same choreography, no persistent architect collaborator. One of the two will win on feel and the other gets deleted.

## What it adds

- **`/plan` command** (and `/goal/plan`) — goal-ready planning: proactive research (with user grilling when the ask underdetermines the work) → outline approval by the user → rubric-driven draft → cold adversarial review → judge rubric verification → `submit_plan`. The main agent designs the outline itself and is required to state why the chosen shape won over an alternative.
- **`adversarial_review` tool** — independent, read-only reviews run in parallel, one per configured review model (`reviewModel1`–`reviewModel3`, each with the model picker; falls back to the session model when none are set). Each reviewer keeps its own memory per plan (thread `<parentThreadId>--<planSlug>--<modelSlug>`): the first round arrives cold — no session framing, everything arrives in the prompt — and later rounds (re-reviews after fixes, the implementation review) continue that reviewer's conversation instead of re-orienting from zero, with instructions to re-verify claimed fixes against the code rather than trusting them. Reports Must fix / Risks & questions / Suggested improvements; overlapping findings across models are a high-confidence signal.
- **`plan-rubric` skill** — the goal-ready plan rubric (phased structure, verification gates, progress file, ship checks, adversarial review, review-handoff human approval gate).
- **`new-pr` skill** — after the user approves completed work, push and open a PR in the browser for final editing.

## Why

Goal mode executes plans autonomously — plan defects are expensive. Single-agent planning has anchor bias and no design review. This plugin keeps planning cheap and single-headed, and buys the second opinion with cold multi-model adversarial reviews instead of a persistent design collaborator.

## Install

```
/plugins install mastra-ai/plan
```

Optionally set `reviewModel1`–`reviewModel3` to strong models from different families.

## Development

```
pnpm install
pnpm link <path-to-local-mastracode>
pnpm check
```
