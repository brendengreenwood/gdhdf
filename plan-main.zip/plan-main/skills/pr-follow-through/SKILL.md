---
name: pr-follow-through
description: Follow a PR after it opens — subscribe to it when a PR-subscription tool is available, fix CI failures, and handle review comments, acting autonomously only above a confidence bar and asking the user below it. Use immediately after opening any PR (a new-pr handoff or a plan set's segment draft PRs) and whenever subscribed-PR notifications arrive.
---

# PR follow-through

Opening a PR isn't the end of the work — CI can fail and reviewers will comment. This skill covers staying on the PR until it's mergeable: subscribe, triage what comes in, act where confidence is high, ask where it isn't.

## Subscribe

Right after a PR is opened, check whether the current runtime has a PR-subscription tool (e.g. `github_subscribe_pr`). If it does, subscribe to the PR — CI results and review activity will then arrive as notifications in this thread. If no subscription tool exists, say so in one line ("no PR subscription available — ping me to check CI/comments") and stop here; don't poll.

Subscription is follow-through, not authorization: it changes *when* you learn about failures and comments, never what you're allowed to do about them. The confidence bar below applies identically to notified and manually-requested triage.

## In goal mode

When the PR belongs to a goal run, opening it does not finish the goal — follow-through is in-contract goal work. After every follow-through action or report, the correct judge verdict is **waiting** (for CI results, review activity, or the user), never **complete**. The goal completes only when the PR is merged or the user explicitly confirms the work is fully done.

## The confidence bar

Every incoming item — a CI failure, a review comment — gets sorted into **act** or **ask**. The default is ask; acting is what has to qualify.

**Act autonomously only when ALL of these hold:**

- **Evidenced root cause** — you can point from the failing log line to the exact code, and you reproduced the failure locally (or the class is mechanical: lint, formatting, a type error introduced by this branch, a missing changeset).
- **One clearly-correct fix** — not a choice between plausible fixes with different tradeoffs.
- **In-scope and design-preserving** — the fix stays within the PR's existing scope and approved design: no public contract changes, no new dependencies, no do-not-list items (when the PR came from a plan), no behavior the user hasn't already approved.
- **Review-nit sized** — roughly the scale of a change a reviewer would call a nit. Anything a reviewer would want to re-review from scratch is above the bar.

**Ask the user when ANY of these hold:**

- The root cause is a hypothesis — you can't reproduce it, or the fix is a guess that "should" work.
- Multiple plausible fixes exist with different tradeoffs.
- The fix would alter the approved design, a public API, or the meaning of a test.
- A reviewer requests scope expansion, or their direction conflicts with the plan or something the user said.
- The failure looks pre-existing or unrelated to the branch — report it with evidence; fixing other people's breakage in this PR is scope creep even at high confidence.

When asking, use the one-question-per-stop pattern with a recommendation: state the item, your diagnosis with evidence, the options (do X — recommended / do Y / skip and reply to the reviewer explaining why / tell me more), and wait. Don't batch dependent decisions.

**Never autonomous, regardless of confidence:** weakening or deleting a test assertion to make CI green, skipping a test, force-pushing over review history, resolving another person's comment thread, or pushing a change the user explicitly deferred.

## CI failures

1. Read the actual failure log (`gh run view <id> --log-failed` or `gh pr checks`) — never diagnose from the check name alone.
2. Reproduce locally with the repo's focused test command before changing anything.
3. Suspected flake: rerun once (`gh run rerun <id> --failed`) and say so; if it fails again, it's real and gets the confidence bar like everything else.
4. Above the bar: fix, run the focused verification locally, commit (subject references what broke), push. Below: ask.

## Review comments

Fetch all review comments, not just top-level, and skip resolved threads. For each unresolved comment:

- **Above the bar** (concrete, mechanical, in-scope — typos, renames, a guard the reviewer spelled out, a test they described): implement it, one commit per comment, then reply on the thread with what changed and the commit sha. Let the reviewer resolve their own thread.
- **Below the bar** (design questions, scope requests, ambiguous intent, anything conflicting with prior user direction): bring it to the user with your read and a recommended response. The user may want to answer the reviewer themselves — offer that as an option.
- **Questions to the author** that the evidence answers (why is X like this, does this handle Y): draft the reply, show the user, post on their go-ahead — you're speaking on their PR.

## Report either way

Autonomous action is not silent action. After acting on anything, give the user a compact summary: what came in, what you did, commit shas, what's still open. A batch of small fixes is one summary, not one message each. If everything's green and no comments are open, say that too — "PR is green, no unresolved comments" is the state the user is waiting to hear.
