---
name: prove-it
description: Produce runnable, reviewable proof that a change actually works — demo scripts, red/green transcripts, and TUI/browser recordings. Use when a plan's ship checks call for live proof, when the user asks to prove or demo a change, or before handing work to a human reviewer.
---

# Prove it

Proof means the reviewer can **see the real thing in action**: see it failing without the change (for fixes), and see it working with the change. Passing tests are a claim; a demo the human can rerun and watch is proof. Tests verify units — proof exercises the feature the way a real user would.

**Prove it to yourself first.** Proof is part of building, not packaging: bring the demo to life alongside the feature and run it as your own check that the thing actually works — if you haven't watched it work through a real surface, you don't know it works, no matter what the tests say. Don't manufacture artifacts at the end for the reviewer; by the time you're ready for human approval, the proof should be something you already relied on, and presenting it is just showing your work.

**A test run is not a demo.** Writing a test and capturing the runner's output is a verification gate — the plan already has those. A demo enters through a surface a real user reaches: the installed CLI binary, the booted app, the real TUI, a temp project importing the built artifact, the browser. For internal-only behavior, drive the nearest real entry point and observe the effect where it actually lands (e.g. run the real app headless and inspect what it wrote to the DB) — don't fall back to the unit harness. If no user-reachable surface can show the change, say so honestly and claim the exemption; a test dressed up as a demo is worse than no demo, because it launders a claim into looking like proof.

## The proof plan

Proof is planned and approved before it's built. A **proof plan** is a short block, presented to the user before implementation starts (in a planning flow, inside the outline they approve), that answers: *"here's how I'm going to prove this to you and to myself — is this real enough?"* For each claim the change makes, it states:

- The proposed demo method and surface (which row of the surface table, concretely: "a temp project in `.proof/` that installs the packed tarball and runs the new CLI flag").
- **The realism ladder** — the more-real rungs above the proposal (packed-and-installed package → linked build → script against built artifact → …) and why the realer rung isn't needed, if you're proposing anything less than the most real. Realism is the default; stepping down is what requires justification, never the reverse.
- For fixes: how red will be shown (base worktree, side-by-side pair).
- Exemptions claimed, with the reason.

Present it with options the user can actually steer with: the recommendation, the realer alternative(s) as their own options, and always a standing **"not real enough — propose something closer to what a real user does"** option. The approved proof plan is a contract like the rest of the plan — swapping to a less-real method mid-run without surfacing it breaks the contract the same way cutting scope would.

## Artifact layout

All proof artifacts go in `.mastracode/plans/<name>.proof/` — session artifacts, never committed:

- `demo.sh` (or `demo.ts`, a temp project dir, a `.tape` file…) — the runnable demo. **This is the load-bearing artifact**: the reviewer reruns it with one paste instead of reading tests. It must read top-down as a short narrative — a comment per step, orchestration only. Fixtures (test files, sample projects, input data) live as their own files in `.proof/` that the demo copies into place; a script that's mostly heredoc is unreadable and its fixture is unreviewable.
- `without.txt` — captured transcript of the demo failing on the base commit (fixes only)
- `with.txt` — captured transcript of the demo working on the branch
- Recording files (`.gif` / `.mp4` / `.avi` / Playwright trace) when the surface is visual
- A short `README.md`: what the demo does, how to rerun each piece, what to expect

Transcripts are text so a goal judge can verify red→green with readonly tools. Recordings are for the human.

**Transcripts capture the demo, not the setup.** Installs, builds, and worktree prep are setup — run them before capture starts (or send them to `setup.log`); a transcript that's 500 lines of pnpm/gyp/turbo spew with the verdict on the last line is unreadable, and `diff without.txt with.txt` should be mostly signal. Concretely:

- Capture with colors off (`NO_COLOR=1`, or strip ANSI) so the files are plain text — editors show raw `^[[33m` bytes, only terminals render them. If color/formatting is itself part of the signal (colored diff, rendered TUI state), keep a `.ansi` sibling next to the `.txt` and note in the README that `cat <file>` in a terminal (or an editor ANSI extension) renders it; the plain `.txt` stays canonical.
- `demo.sh` prints an unmistakable verdict line as its last output — e.g. `PROOF: RED — demo failed on base (expected)` / `PROOF: GREEN — demo passed on branch` — so the verdict is grep-able, not inferred from a test runner's summary.
- The interesting output (the captured value, the error, the new behavior) should fit on the reviewer's first screen. If the demo is noisy, have it excerpt the relevant portion.

## The red/green protocol

For fixes, a demo that only runs on the branch is half a proof — show the failure first:

1. Build the demo against the **branch** first and confirm it shows the fixed behavior (write `with.txt`). This proves the demo itself works before you trust it to prove a negative.
2. Run the same demo against the **base**: use a temporary worktree, not stash — `git worktree add /tmp/proof-base <merge-base>` leaves your branch untouched and can't lose state. Capture `without.txt` showing the failure. For temp-project demos, keep this as a live side-by-side pair instead (see Temp projects below).
3. `git worktree remove /tmp/proof-base` when done — unless the side-by-side pair's base copy consumes its build, in which case keep it until the review handoff is approved.
4. If the demo *doesn't* fail on base, stop — either the demo isn't exercising the bug or the fix wasn't needed. That's a finding, not a formality.

For new features, skip `without.txt` unless "base has no way to do this" is itself worth demonstrating (e.g. a new CLI flag erroring on base).

## Choosing the proof by surface

Pick the **most real** surface feasible — the one closest to what an actual user does. A cheaper row is acceptable only when it shows the same behavior the real surface would, and the proof plan says why the realer rung wasn't needed.

| Surface | Demo | Recording (visual surfaces only) |
| --- | --- | --- |
| Library / API | Temp project that installs/links the built package and calls the feature; or a script importing the built artifact | — (transcript is enough) |
| CLI | Script running the real binary with real args; capture stdout/stderr + exit codes | VHS if output formatting matters |
| TUI | tmux checkpoints (below) | VHS tape (below) |
| Web UI | Playwright script (see `webapp-testing` skill if available) | `browser_record` tool if available, else Playwright video/trace |
| Native macOS app | cua-driver skill if available | usually unnecessary — the user can watch live |

**Temp projects** are the strongest demo for anything a user consumes as a package (plugin, SDK, CLI): scaffold in `/tmp` or inside `.proof/`, install the real built artifact (not source imports), exercise the feature, capture output. This catches packaging/entry-point breaks that unit tests structurally cannot.

For fixes, prefer a **side-by-side pair** over one mutating setup: duplicate the demo project as `.proof/demo-base/` (consuming the artifact built from the base worktree) and `.proof/demo-branch/` (consuming the branch build), identical in every other way. Capture `without.txt` from the base copy and `with.txt` from the branch copy, and leave both in place — the reviewer can rerun either on demand and `diff` the two projects/outputs to see exactly what changed. The only permitted difference between the copies is which build they consume; any other drift invalidates the comparison.

## Proof by claim type

A change usually makes several claims at once — a fix can also claim "no extra LLM call" and "same speed." **Prove every applicable claim**, not just the headline one. One demo can carry several claims; the checklist is claims covered, not artifact count.

| Claim | What counts as proof |
| --- | --- |
| "X no longer happens" (negative) | A passing transcript shows nothing — prove absence with a counter or intercept log (model-call log, network intercept, fs watch): base shows the unwanted event, branch shows zero |
| Faster / fewer tokens / less memory | Before/after numbers on **identical input** — `hyperfine` for CLI, token counts on the same fixture conversation — as a side-by-side table. The number is the proof |
| Race / flaky fix | Single red/green is meaningless for a 1-in-20 race. Stress loop: N runs on base fail k/N, N runs on branch fail 0/N — red/green is a ratio; record N |
| What the model receives (prompt-level) | LLM output is stochastic but the assembled prompt is deterministic — capture it on base vs branch **through the real entry point** and diff |
| State transform (migration, data repair) | Before/after dump of the same fixture DB/file, plus the diff |
| Error path (better message, graceful degradation) | The demo must **induce** the failure; capture the failure output on both sides. Happy-path demos pass on both and prove nothing here |
| HTTP/server behavior | Boot the real server, `curl` transcripts (including streaming/SSE chunks when that's the surface) |
| Packaging (exports, files field, bin) | `pnpm pack` + install the tarball into a temp project — symlink shortcuts skip exactly the layer this claim is about |
| Works with real provider/service X | Run it against the real thing with real keys — **required, never waived for cost or key friction**. Mocks are for determinism *in addition to* the real run, never instead of it |

Honest limits that may be stated instead of simulated: cross-platform behavior you can't run locally, and load-at-scale. State the limit and what was verified instead — don't fake the proof.

## TUI: tmux checkpoints (judge-readable)

```sh
tmux new-session -d -s proof -x 200 -y 50 '<the tui command>'
tmux send-keys -t proof '<keys>' # drive it; sleep between steps
sleep 1 && tmux capture-pane -t proof -p > .proof/checkpoint-1.txt
tmux kill-session -t proof
```

Text screenshots of real TUI states — cheap, deterministic enough, and the judge can `view` them against the criteria.

## TUI/CLI: VHS recording (human-facing)

[VHS](https://github.com/charmbracelet/vhs) renders a GIF/MP4 from a `.tape` script — demos-as-code, regenerates deterministically. Check availability with `vhs --version` (install: `brew install vhs`). Keep the tape in `.proof/` next to its output:

```tape
Output .mastracode/plans/<name>.proof/demo.gif
Set Width 1200
Set Height 700
Type "<the command>" Enter
Sleep 3s
Down Sleep 1s     # drive the TUI
Type "q"
```

Caveat: flows that hit real LLMs or the network are stochastic — record the deterministic part, or accept the recording shows one representative run.

## Browser: agent-browser recording

If `browser_record` is available: `browser_record action=start` → drive the flow with the browser tools → `browser_record_caption` after each meaningful step (≤6 words, burned into the video) → `browser_record action=stop` writes a playable video. Move it into `.proof/`. Captions turn the video into a narrated demo — use them.

Without it, Playwright: a trace (`show-trace` gives DOM snapshots + network + timeline) is the better *inspection* artifact; video is the better *watch it work* artifact. Capture whichever the reviewer needs, or both.

## Scaling guard

Don't turn a one-line fix into a film production:

- Demo script + transcript(s): required for any user-observable behavior change
- Every applicable claim type (table above) gets covered — but one demo may cover several
- Recording: only when the surface is visual and a transcript can't capture it
- Neither: pure refactors, type-level changes, doc changes — the test suite and diff are the proof

## Reporting

In the review handoff / final report, the Manual proof section becomes: the one-paste rerun command, what to expect, the red transcript path (for fixes), and the recording path if one exists. Don't paste full transcripts into the report — reference the files.
