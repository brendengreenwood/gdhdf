---
name: new-pr
description: Open a pull request for the current branch in the user's browser for final editing. Use after completed work is approved and the user wants a PR — e.g. at the end of a goal run's human approval gate, or whenever the user asks to open a PR.
---

# Opening a PR

Use the gh CLI to create a **draft PR** for the current branch, then open it in the user's browser with the OS `open` command. Creating it as a draft (instead of `--web`, which only pre-fills a form) means the PR exists immediately — CI starts and it can be subscribed to right away — while the user keeps full control: they edit the title/description in the browser and mark it ready for review when satisfied. Never create a non-draft PR directly.

Push first — a PR can't be opened without pushing the changes up.

## Scope

Make sure you fully understand the scope of the PR before writing anything. It's annoying to the user if the PR reads as being about the most recent commit only — understand what the whole branch is about (`git log main..HEAD --oneline`, or the plan/progress file if this is a goal run).

## Title

Descriptive and concise, using conventional commits (e.g. `fix: $TITLE`).

## Description

Concise and humble — no flowery or overly verbose language. Casual/friendly but get to the point. Show simple code examples: before/after for fixes, just after for new features. No lists or headings. Keep it simple.

Word it to explain the whole unit of work to someone who knows nothing about it. Don't include fixes and detours that happened along the way.

## Shell safety

When the PR body contains multiple lines, code fences, backticks, or other characters that are easy to break in shell escaping, do not inline it in the command string. Write it to a temp file with a quoted heredoc:

```sh
cat <<'EOF' > /tmp/pr-body.md
...body exactly as written...
EOF
gh pr create --draft --title "..." --body-file /tmp/pr-body.md
rm /tmp/pr-body.md
```

The quoted `EOF` matters — it prevents the shell from expanding backticks, `$variables`, or backslashes inside the body.

`gh pr create` prints the new PR's URL on stdout. Open it in the user's browser (macOS: `open <url>`; Linux: `xdg-open <url>`) so they can review, edit, and mark it ready.

## After the PR is open

If the current runtime has a PR-subscription tool (e.g. `github_subscribe_pr`), subscribe to the newly created draft PR immediately — don't wait for the user to mark it ready — and activate the `pr-follow-through` skill if available. CI failures and review comments arrive as notifications and get triaged through its confidence bar (act on mechanical, evidenced, in-scope fixes; ask the user for anything design-shaped or uncertain). Without the subscription tool, tell the user follow-through is on request.

In a goal run, opening the PR does not finish the goal — the goal stays open through follow-through (verdict *waiting*, not *complete*) until the PR merges or the user explicitly confirms the work is done.
